#include "mdp_all.h"

void f(VectorGC<float> y) {
    y[1]=57;
}

void print(VectorGC<float> x) {
    for(int i=0; i<x.length(); i++)
       cout << x[i] << endl;
}

int main(int argc, char *argv[])
{

  VectorGC<float> a(3);
  VectorGC<float> b;

  for(int i=0; i<a.length(); i++) a[i]=i*i;
  b=a;
  b[1]=100;
  cout << "references of a " << a.refcount() << endl;
  cout << "references of b " << b.refcount() << endl;  
  print(a);
  system("PAUSE");	
  return 0;
}
