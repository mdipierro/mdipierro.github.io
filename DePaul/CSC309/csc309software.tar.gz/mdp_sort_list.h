// /////////////////////////////
// FILE: test_sort.h
// written by Massimo Di Pierro
// /////////////////////////////

void sort_list_of_string() {
  int i;
  String input;
  cout << "Insert array elements ([ENTER] to finish)\n";
  List<String> a;
  for(i=0;; i++) {
    cout << "a[" << i << "]="; cin >> input;
    if(input!="") a.append(input); else break;
  }
  InsertionSort(a);
  cout << "Sorted list:\n";
  for(i=0;i<a.length(); i++) {
    cout << "a[" << i<< "]=" << a[i] << endl;
  }
}


