// ///////////////////////////
// FILE: mdp_list.h
// Written by Massimo Di Pierro
// ///////////////////////////
/*
--------------------------
     Method Summary
--------------------------
void append(T a)  //append a node at the end of the list.
void insert(int i, T a)  //insert a node at index i.
void remove(int i)  //remove the node at index i.
void erase()  //erase all nodes in the list.
int length()  //return the length of the list.

*/


// class List, a linked list of object of objects of class T (for any T)

template <class T>
class List {
 protected:

  // member class Node, a node of the List
  // each node stores a value and a pointer to the next node

  class Node {
   public:
     T     value;
     Node* next;
     Node(T a, Node* b=0) {
      value=a;
      next=b;
     }
  }; // end class


 // Member variables are: head (a pointer to the first Node)
 // and size (the number of Nodes in the List)

 private:
  Node* head;
  Node* tail;
  int size;

 public:

  // Constructor

  List() {
    head=0;
    tail=0;
    size=0;
  }

  // Destructor

  virtual ~List() { // constructor
    erase();
  }

  // Remove all nodes from list

  void erase() {
    for(int j=size-1; j>=0; j--) remove(j);
  }

  // Copy Constructor

  List(const List& list) {
    head=0;
    size=0;
    for(int i=0; i<list.length(); i++) append(list[i]);
  }

  // Assignment operator

  List& operator=(const List& list){
    erase();
    for(int i=0; i<list.length(); i++) append(list[i]);
    return (*this);
  }

  // Append a new Node (storing the value of a) to the list

  void append(T a) {
    if(head==0) {
      tail=head=new Node(a,0);
    } else {
      (*tail).next=new Node(a,0);
      tail=(*tail).next;
    }
    size++;
  }

  // Return (by reference) the value stored by Node number i

  T& operator[](int i) {
    if(i<0 || i>=size) throw Exception("ListIndexOutOfBoundsException");
    Node* p=head;
    for(int j=0; j<i; j++) p=(*p).next;
    return (*p).value;
  }

  // Return (by reference) the value stored by Node number i, in const functions

  const T& operator[](int i) const {
    if(i<0 || i>=size) throw Exception("ListIndexOutOfBoundsException");
    Node* p=head;
    for(int j=0; j<i; j++) p=(*p).next;
    return (*p).value;
  }

  // Insert a Node (storing the value of a) at position i in the List

  void insert(int i, T a) {
    if(i<0 || i>=size) throw Exception("ListIndexOutOfBoundsException");
    if(i==0) {
      head=new Node(a,head);
    } else {
      Node* p=head;
      for(int j=0;j<i-1;j++) p=(*p).next;
      (*p).next=new Node(a,(*p).next);
    }
    size++;
  }

  // Remove Node i from the List

  void remove(int i) {
    Node* q;
    if(i<0 || i>=size) throw Exception("ListIndexOutOfBoundsException");
    if(i==0) {
      q=head;
      head=(*head).next;
      delete q;
      if(head==0) tail=0;
    } else {
      Node* p=head;
      for(int j=0;j<i-1;j++) p=(*p).next;
      q=(*p).next;
      (*p).next=(*q).next;
      if(tail==q) tail=p;
      delete q;
    }
    size--;
  }

  // Return number of Nodes in the List

  int length() const {
    return size;
  }

}; // end class 

// Send the List list to the output stream os

template<class T>
ostream& operator<<(ostream& os, const List<T>& list) {
  os << "[";
  if(list.length()>0) os << list[0];
  for(int j=1; j<list.length(); j++) os << ", " << list[j];
  os << "]";
  return os;
}

// Return true if List and List b have the same length 
// and store the same values in the same order false otherwise

template<class T>
bool operator==(const List<T>& a, const List<T>& b) {
  if(a.length()!=b.length()) return false;
  for(int i=0; i<a.length(); i++) if(a[i]!=b[i]) return false;
  return true;
}

// Return false if List and List b have the same length and store the same values in the same order
// true otherwise

template<class T>
bool operator!=(const List<T>& a, const List<T>& b) {
  return !(a==b);
}

