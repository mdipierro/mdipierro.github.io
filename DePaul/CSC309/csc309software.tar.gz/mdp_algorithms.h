// ///////////////////////////
// FILE: mdp_algorithms.h
// Written by Massimo Di Pierro
// ///////////////////////////

// Return the Minimum of  a and b (whatever a and b are, as long they are comparable, i.e. have operator<)

template<class T>
T Min(const T& a, const T& b) {
  if(a<b) return a;
  return b;
}

// Return the Maximum of  a and b (whatever a and b are, as long they are comparable, i.e. have operator>)

template<class T>
T Max(const T& a, const T& b) {
  if(a>b) return a;
  return b;
}

// Swap the values of a and b (whatever a and b are, note they are passed by reference)

template<class T>
void Swap(T& a, T& b) {
  T c=a;
  a=b;
  b=c;
}

// Sort elements of A (using operator[] to access elements and operator< and operator> to check relations)
// starting at element p and terMinating at element r-1

template<class T>
void InsertionSort(T& A, int size) {
  int i,j;
  for(i=1; i<size; i++)
    for(j=i-1;j>=0; j--) {
      if(A[j]>A[j+1]) Swap(A[j],A[j+1]);
      else break;
    }
}

// Sort all elements of A (using operator[] to access elements and operator< and operator> to check relations)

template<class T>
void InsertionSort(T& A) {
  InsertionSort(A,A.length());
}

