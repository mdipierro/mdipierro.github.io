// ///////////////////////////
// FILE: test.cpp
// Written by Massimo Di Pierro
// ///////////////////////////

#include "mdp_all.h"
#include "test_stack.h"
#include "test_sort.h"
#include "test_replace_string.h"

int main() {
  String choice;
  cout << "EXAMPLE SOFTWARE ACCOMPANING THE COURSE:\n";
  cout << "Object Orinted Programming in C++\n";
  cout << "developed by Massimo Di Pierro\n";
  cout << "\n";
  try {
    while(true) {
      cout << "\n\nYour options are:\n";
      cout << "0) run test_stack()\n";
      cout << "1) run replace_string()\n";
      cout << "2) run sort_string()\n";
      cout << "3) run sort_vector_of_int()\n";
      cout << "4) run sort_vector_of_string()\n";
      cout << "5) run sort_list_of_string()\n";
      cout << "6) run main_database()\n";
      cout << "7) run play_blackjack();\n";
      cout << "e) exit\n";     
	  cout << "What do you want to do?";
	  cin >> choice;
	  cout << "\n\n\n";
      if(choice.length()>0) switch(choice[0]) {
       case '0': test_stack();            break;
       case '1': replace_string();        break;
	   case '2': sort_string();       break;
       case '3': sort_vector_of_int();    break;
       case '4': sort_vector_of_string(); break;
       case '5': sort_list_of_string();   break;
       case '6': main_map();              break;
       case '7': play_blackjack();        break;
       case 'e': throw 0;
      }
    }
  } catch(Exception e) {
    cout << "Runtime error: " << e.value() << endl;
  } catch(int) {
    cout << "bye bye ...\n";
  }
  return 0;
}
