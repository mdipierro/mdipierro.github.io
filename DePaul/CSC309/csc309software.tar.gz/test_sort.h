// /////////////////////////////
// FILE: test_sort.h
// written by Massimo Di Pierro
// /////////////////////////////

void sort_string() {
  String s;
  cout << "Input a String:"; cin >> s;
  InsertionSort(s);
  cout << "Sorted String :" << s << endl;
}

void sort_list_of_string() {
  int i;
  String input;
  cout << "Insert array elements ([ENTER] to finish)\n";
  List<String> a;
  for(i=0;;i++) {
    cout << "a[" << i << "]="; cin >> input;
    if(input!="") a.append(input); else break;
  }
  InsertionSort(a);
  cout << "Sorted list:\n";
  for(i=0;i<a.length(); i++) {
    cout << "a[" << i<< "]=" << a[i] << endl;
  }
}

void sort_vector_of_int() {
  int i;
  cout << "Elements of the vector (1-10):"; cin >> i;
  cout << endl;
  Vector<int> a(i);
  for(i=0;i<a.length(); i++) {
    cout << "a[" << i<< "]="; cin >> a[i];
  }
  InsertionSort(a);
  cout << "Sorted vector:\n";
  for(i=0;i<a.length(); i++) {
    cout << "a[" << i<< "]=" << a[i] << endl;
  }
}

void sort_vector_of_string() {
  int i;
  cout << "Elements of the vector (1-10):";
  cin >> i;
  Vector<String> a(i);
  for(i=0; i<a.length(); i++) {
    cout << "a[" << i << "]="; cin >> a[i];
  }
  InsertionSort(a);
  cout << "Sorted vector:\n";
  for(i=0;i<a.length(); i++) {
    cout << "a[" << i<< "]=" << a[i] << endl;
  }
}

