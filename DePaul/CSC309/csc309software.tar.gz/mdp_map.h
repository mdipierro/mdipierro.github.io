// ///////////////////////////
// FILE: mdp_map.h
// Written by Massimo Di Pierro
// ///////////////////////////
/*
--------------------------
     Method Summary
--------------------------
int recordIndex(const S& key) //return the index that corresponds to the key passed.
bool hasKey(const S& key) //return true if the key is in list of Record's.
void appendRecord(const S& key, const T& body) //append a record to the end of the list.
bool deleteRecord(const S& key)  //delete the record that matches the key.
bool save(String filename)  //save a Map into a file.
bool load(String filename)  //Load a Map from a file.

*/


// class to store a Record<S,T> of the Map<S,T>
// each record stores a key of class S and a record body of class T

template<class S, class T>
class Record {
public:
  S key;
  T body;

  // Constructors

  Record() {}
  Record(const S&  s) {
    key=s;
  }
  Record(const S&  s, const T& t) {
    key=s;
    body=t;
  }
  
  // Operators required for sorting
  
  friend bool operator<(const Record &a, const Record& b) {
    return (a.key<b.key);
  }
  friend bool operator>(const Record &a, const Record& b) {
    return (a.key>b.key);
  }
  friend ostream& operator<<(ostream& os, const Record& record) {
    os << record.key << ":" << record.body;
    return os;
  }

};

// class Map<S,T> of Record<S,T>, the Map is implemented as a List of Record(s)

template<class S, class T>
class Map : public List<Record<S,T> > {
 public:
  
  // Constructor
  Map() { 
    // REQUIRED!!! calls List::List()
  }
  
  // Return the position in the Map of the first Record with key equal to key
  
  int recordIndex(const S& key) const {
    for(int i=0; i<length(); i++) 
      if((*this)[i].key==key) return i;
    return -1;
  }  
  
  // Check if the Map contains a Record with key equal to key
  
  bool hasKey(const S& key) const {
    if(recordIndex(key)<0) return false;
    return true;
  }
  
  // Append a new Record to the Map
  
  void appendRecord(const S& key, const T& body) {
    append(Record<S,T>(key,body));
    InsertionSort(*this);
  }
  
  // Delete from the Map the first record with key equal to key
  
  bool deleteRecord(const S& key) {
    int i=recordIndex(key);
    if(i<0) return false;
    remove(i);
    return true;
  }
  
  // Return (by reference) the body of the Record whose key is equal to key
  
  T& operator()(const S& key) {
    int i=recordIndex(key);
    if(i<0) append(Record<S,T>(key));
    i=recordIndex(key);
    return (*this)[i].body;
  }
  
  // Return (by reference) the body of the Record whose key is equal to key, in const functions
  
  const T& operator()(const S& key) const {
    int i=recordIndex(key);
    if(i<0) throw Exception("MapIndexOutOfBounds");
    return (*this)[i].body;
  }
  
  // Save the Map into file filename
  
  bool save(String filename) {
    ofstream file;
    file.open(filename.c_str());
    for(int i=0; i<length(); i++) {
      file << "RECORD N. " << i << endl;
      file << (*this)[i].key  << endl;
      file << (*this)[i].body << endl;
    }
    file.close();
    return true;
  }
  
  // Load the Map from file filename
  
  bool load(String filename) {
    String dummy;
    S key;
    T body;
    ifstream file;
    file.open(filename.c_str());
    if(!file) return false;
    while(true) {
      file >> dummy;
      if(file.fail()) break;
      file >> key;
      file >> body;
      appendRecord(key,body);
    }
    file.close();
    return true;
  }
};

// Text mode Map interface for Map<String, String>

void main_map() {
  int i;
  String choice, key, body, filename;
  Map<String,String> db;
  while(true) {
    cout << "\na)ppend  d)elete  f)ind  p)rint"
      "\nl)oad    s)ave           e)xit"
			"\nYour choce:";
    cin >> choice;
    switch(choice[0]) {
    case 'a':
      cout << "Key :"; cin >> key;
	  cout << "Body:"; cin >> body;
	  db.appendRecord(key,body);
	  break;
    case 'd': 
      cout << "Key :"; cin >> key;
      if(db.hasKey(key)) db.deleteRecord(key);
	  break;
    case 'f': 
      cout << "Key :"; cin >> key;
      if(db.hasKey(key)) cout << "Body:" << db(key) << endl;
      break;
    case 'p': 
      for(i=0; i<db.length(); i++)
	cout << i << " : " << db[i].key 
	     << " : " << db[i].body << endl;
      break;
    case 'l':
      cout << "load data from file:";
      cin >> filename;
      db.load(filename);
      break;
    case 's':
      cout << "save data to file:";
      cin >> filename;
      db.save(filename);
      break;
    case 'e': 
      return;
    }
  }
}

