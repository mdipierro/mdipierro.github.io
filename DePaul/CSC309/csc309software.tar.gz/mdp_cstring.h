// ///////////////////////////
// FILE: mdp_cstring.h
// Written by Massimo Di Pierro
// ///////////////////////////

// Example of functions that acts on C-strings

// Send a C-string p to the output stream os

ostream& operator<< (ostream& os,
                     char* p) {
  for(;*p!='\0';p++) os << *p;
  return os;
}

// Count the number of characters in the C-string p (not counting the termination character �\0�)

int strlen(char* p) {
  int length=0;
  for(;(*p)!='\0';p++) length++;
  return length;
}

// Copy the C-string p into the C-string q (including the termination character)

void strcpy(char *q, char* p) {
  int i;
  for(i=0; i<strlen(p)+1; i++) q[i]=p[i];
}

void strcat(char *q, char* p) {
  int i, j=strlen(q);
  for(i=0; i<strlen(p)+1; i++) q[i+j]=p[i];
}

int strcmp(char *q, char* p) {
  int i;
  for(i=0; i<strlen(p)+1; i++)
    if(q[i]<p[i])      return -1;
    else if(q[i]>p[i]) return +1;
  return 0;
}


