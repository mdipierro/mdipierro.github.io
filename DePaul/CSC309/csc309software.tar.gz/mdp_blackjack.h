// ///////////////////////////
// FILE: blackjack.h
// Written by Massimo Di Pierro
// ///////////////////////////

// Simulator for the game of Blackjack

// class to store a bjCard (reads (Blackjack Card),
// c (or color) is the color of the class (0,1,2,3) and v (or value)
// is its value ( 1 to 10)

class bjCard {
public:
  int c;
  int v;
  int color() const {
    return c;
  }
  int value() const {
    return v;
  }

  // Constructors

  bjCard() { }
  bjCard(int cc, int vv) {
    c=cc;
	v=vv;
  }
};

// class bjDeck, a deck of bjCard(s), implemented as a List of bjCard(s)

class bjDeck : public List<bjCard> {
public:

  // Useful constants

  enum {minColor=0, maxColor=3, minValue=1, maxValue=10 };

  // Constructor

  bjDeck() {
	int color, value;
	for(color=minColor; color<=maxColor; color++)
      for(value=minValue; value<=maxValue; value++)
        append(bjCard(color,value));
  }

  // Shuffle the Deck  n times

  void shuffle(int n=2) {
    int i,j,k;
    for(k=0; k<n; k++) {
		for(i=0; i<length(); i++) {
          j=rand() % length();
		  swap((*this)[i],(*this)[j]);
		}
	}	  
  }

  // Return the first Card from the top of the Deck and remove it from the Deck

  bjCard getCard() {
     if(length()==0) 
       throw Exception("bjDeckEmptyExcpetion");
     bjCard topcard=(*this)[0];
	 remove(0);
	 return topcard;
  }
};

// Basic class for a Blackjack player

class bjPlayer {
public:

  // each player has a name, a hand (=Cards in his hand)
  // a bet and a portfolio with some money

  String name;
  List<bjCard> hand;
  int bet;
  int portfolio;

  // Constructor

  bjPlayer() {
	portfolio=0;
	handReset();
  }

  // Set bet to zero and remove all cards from the player�s hand

  void handReset() {
	bet=0;
    hand.erase();
  }

  // Player asks for a card from the Deck deck

  void askCard(bjDeck& deck) {
    hand.append(deck.getCard());
  }

  // value (score) of the cards in the player�s hand

  int handValue() const {
    int value=0;
	for(int i=0; i<hand.length(); i++)
      value=value+hand[i].value();
	return value;
  }

  // player�s strategy (virtual because there may be different strategies)

  virtual void play(bjDeck&)=0;
};

// Here are players with different game strategies

// This is the Dealer

class bjDealer : public bjPlayer { 
public:
  void play(bjDeck& deck) {
	while(handValue()<17) askCard(deck);
  }
};

// This is a student.. plays conservatively

class bjStudent : public bjPlayer { 
public:
  void play(bjDeck& deck) {
    bet=100;
    while(handValue()<15) {
		bet=bet+100;
		askCard(deck);
	}
  }
};

// This is a James Bond kind of player, always double the bet

class bjJamesBond : public bjPlayer { 
public:
  void play(bjDeck& deck) {
    bet=100;
    while(handValue()<19) {
		bet=2*bet;
		askCard(deck);
	}
  }
};

// This is an interactive player (ask the console what to do)

class bjInteractive : public bjPlayer { 
public:
  void play(bjDeck& deck) {
	int i, b, c;
	bet=0;
	cout << "\nYour turn " << name << endl;
    while(handValue()<21) {
      cout << "You have the following cards:\n";
      for(i=0; i<hand.length(); i++) cout << hand[i].value() << " ";
	  cout << "\nHow much do you want to bet? ";
	  cin >> b;
      bet=bet+b;
	  cout << "Your total bet is " << bet << endl;
	  cout << "Do you want a card (0 - no, 1, yes)?";
	  cin >> c;
	  if(c==1) askCard(deck); else break;
	}
  }
};

// Main function for to play the Blackjack game

void play_blackjack() {
  bjDeck fulldeck, deck;
  List<bjPlayer*> players;
  int i,match, nmatches=100;

  // selecet the players
  players.append((bjPlayer*) new bjDealer);
  players.append((bjPlayer*) new bjStudent);
  players.append((bjPlayer*) new bjJamesBond);
  // uncomment this to play the game
  //  players.append((bjPlayer*) new bjInteractive);	
  //  players[players.length()-1]->name="Massimo";

  for(match=0; match<nmatches; match++) {

	// take a new card deck and shuffle it
    deck=fulldeck;
	deck.shuffle();

	// each player asks for two cards and plays
	for(i=0; i<players.length(); i++) {
	  players[i]->handReset();
      players[i]->askCard(deck);
	  players[i]->askCard(deck);
      players[i]->play(deck);
	}

	// settle bets according to rules of the game
    for(i=1; i<players.length(); i++) {
       if(players[i]->handValue()<=21 &&
		  (players[i]->handValue()>players[0]->handValue() ||
		   players[0]->handValue()>21)) {
		  players[i]->portfolio+=players[i]->bet;
		  players[0]->portfolio-=players[i]->bet;
	   } else {
   		  players[i]->portfolio-=players[i]->bet;
   		  players[0]->portfolio+=players[i]->bet;
	   }
	}

	// print outcome of the match
    cout << "MATCH N. " << match << endl;
    for(i=0; i<players.length(); i++) {
	  cout << "  player: " << i << " " << players[i]->name
	       << ", bet: " << players[i]->bet
	       << ", hand:" << players[i]->handValue()
	       << ", portfolio: " << players[i]->portfolio << endl;
	}
  }
  // deallocate players
  for(i=players.length()-1; i>=0; i--) {
	delete players[i];
	players.remove(i);
  }
}


