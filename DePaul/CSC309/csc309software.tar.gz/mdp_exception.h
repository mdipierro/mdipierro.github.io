// /////////////////////////////
// FILE: mdp_exception.h
// written by Massimo Di Pierro
// /////////////////////////////

class Exception {

private: 
    char *message;
public:
    Exception(char* m) {
      if(m!=0) {
	message=new char[strlen(m)+1];
	strcpy(message,m); 
      } else message=0;
    }
    ~Exception() {
      if(message!=0) delete[] message;
    }
    Exception(const Exception& a) {
      if(a.message!=0) {
	message=new char[strlen(a.message)+1];
	strcpy(message,a.message); 
      } else message=0;      
    }
    Exception& operator=(const Exception& a) {
      if(&a==this) return (*this);
      if(message!=0) delete[] message;      
      if(a.message!=0) {
	message=new char[strlen(a.message)+1];
	strcpy(message,a.message); 
      } else message=0;      
      return (*this);
    }
    const char* value() const {
        return message;
    }
};





