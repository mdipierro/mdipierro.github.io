// ///////////////////////////
// FILE: mdp_vectorgc.h
// Written by Massimo Di Pierro
// ///////////////////////////\

// Generic class VectorGC of T, where T can be any type of object

template<class T>
class VectorGC2 : public Vector<T> {
 public:
  int counter;
  VectorGC2(int i=0) : Vector<T>(i) {
    counter=1;
  }
  friend ostream& operator<<(ostream& os, const VectorGC2& a) {
    cout << "[";
    if(a.size>0) cout << a[0];
    for(int j=1; j<a.size; j++) cout << ", " << a[j];
    cout << "]";
    return os;
  }
}; // end class

template<class T>
class VectorGC {
    private:
    VectorGC2<T>* pointer;
    public:
    VectorGC(int i=0) {
        pointer=new VectorGC2<T>(i);
    }

  void resize(int i) {
    (*pointer).resize(i);
  }
  // Destructor

  virtual ~VectorGC() {
    (*pointer).counter--;
    if((*pointer).counter==0) {
        delete pointer;
    }
  }

  // Copy Constructor

  VectorGC(const VectorGC<T>& a) {
    pointer=a.pointer;
    (*pointer).counter++;
  }

  VectorGC(const VectorGC2<T>& a) {
    pointer=new VectorGC2<T>;
    (*pointer)=a;    
  }

  VectorGC(const VectorGC<T>* p) {
    pointer=new VectorGC2<T>;
    (*pointer)=*(p->pointer);
    delete p;
  }

  VectorGC2<T>& clone() {
    return (*pointer);
  }

  // Assignment operator

  VectorGC& operator=(const VectorGC& a){
    if(&a==this) return (*this);
    (*pointer).counter--;
    if((*pointer).counter==0) {
        delete pointer;
    }
    pointer=a.pointer;
    (*pointer).counter++;    
    return (*this);  
  }

  // operator[] to access individual VectorGC elements

  float& operator[](int i) {
    return (*pointer)[i];
  }

  // operator[] to access individual VectorGC elements in a const function

  const float& operator[](int i) const {
    return (*pointer)[i];  
  }

  // Return the number of elements in the VectorGC

  int length() const { 
    (*pointer).length();
  }

  int refcount() {
    return (*pointer).counter;
  }

  // Send the VectorGC a to the output stream os

  friend ostream& operator<<(ostream& os, const VectorGC& a) {
    os << *((Vector<T>*) &a);
    return os;
  }
};

// Return true if VectorGC a and VectorGC b are equal (contain same elements), false otherwise

template<class T>
bool operator==(const VectorGC<T>& a, const VectorGC<T>& b) {
  if(a.length()!=b.length()) return false;
  for(int i=0; i<a.length(); i++) if(a[i]!=b[i]) return false;
  return true;
}

// Return true if VectorGC a and VectorGC b are not equal (contain same elements), false otherwise

template<class T>
bool operator!=(const VectorGC<T>& a, const VectorGC<T>& b) {
  return !(a==b);
}


