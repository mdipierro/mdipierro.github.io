// include the math library
#include "cmath"  

// include the C-style string functions: strlen, strcpy, strcmp, strcat
#include "cstring"

// include extra stuff: system, randomize, rand
#include "cstdlib"

// include time functions
#include "ctime"

// include IO stream functions
#include "iostream"

// incude File IO stream functions
#include "fstream"

// use the std namespace (access function in above) libraries)
using namespace std;

// include mdp_ headers
#include "mdp_scaffolding.h"
#include "mdp_exception.h"
#include "mdp_stack.h"
#include "mdp_queue.h"
#include "mdp_algorithms.h"
#include "mdp_vector.h"
#include "mdp_string.h"
#include "mdp_list.h"
#include "mdp_map.h"
#include "mdp_binarysearchtree.h"
#include "mdp_vectorgc.h"
#include "mdp_blackjack.h"

