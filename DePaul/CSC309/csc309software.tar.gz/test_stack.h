// ///////////////////////////
// FILE: test_stack.h
// Written by Massimo Di Pierro
// ///////////////////////////

void test_stack() {
  int i,j;
  cout << "How many elements in the stack?";
  cin >> i;
  Stack stack(i);
  while(true) {
    cout << "\n1)push 2)pop 3)exit. Your choice:";
    cin >> i;
    switch(i) {
    case 1: if(stack.isFull()) {
              cout <<"Sorry...stack full\n";
            } else {
              cout << "Insert a number to push:";
              cin >> j;
              stack.push(j);
            }
            break;
    case 2: if(stack.isEmpty()) {
              cout << "Sorry...stack empty:";
            } else {
              cout << "This number poped:";
              cout << stack.pop() << endl;
            }
            break;
    case 3: return;
    }
  }
}

