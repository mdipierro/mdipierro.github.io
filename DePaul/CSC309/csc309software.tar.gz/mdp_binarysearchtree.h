/////////////////////////////////
// FILE: mdp_binarysearchtree.h
// Written by Massimo Di Pierro
/////////////////////////////////

class BSTNode {
    public:
    float value;
    BSTNode* left;
    BSTNode* right;    
    BSTNode(float x) {
        value=x;
        left=0;
        right=0;
    }
};

class BSTree {
    private:
    BSTNode* root;
    void recursivelyDelete(BSTNode* p) {
        if(p==0) return;
        recursivelyDelete((*p).left);
        recursivelyDelete((*p).right);        
        delete p;
    }
    void appendSubTree(BSTNode* p) {
        if(p==0) return;
        insertValue((*p).value);    
        appendSubTree((*p).left);
        appendSubTree((*p).right);        
    }
    void recursivePrintTree(BSTNode* p, String spaces="") {
        if(p==0) cout << spaces << "Null" << endl;
        else {
           cout << spaces << (*p).value << endl;
           recursivePrintTree((*p).left, spaces+"   ");
           recursivePrintTree((*p).right, spaces+"   ");        
        }           
    }
    void recursiveInorderPrintTree(BSTNode* p) {
        if(p!=0) {
           recursiveInorderPrintTree((*p).left);
           cout << (*p).value << endl;
           recursiveInorderPrintTree((*p).right);        
        }           
    }


    public:
    BSTree() {
        root=0;
    }
    ~BSTree() {
        recursivelyDelete(root);
    }
    BSTree(const BSTree& other) {    
        appendSubTree(other.root);    
    }

    BSTree& operator=(const BSTree& other) {
      if(&other==this) return (*this);
        // same as destructor
        recursivelyDelete(root);      
        root=0;
        // same as copy constructor
        appendSubTree(other.root);          
      return *this;
    }
    void insertValue(float x) {
        if(root==0) root=new BSTNode(x);
        BSTNode* p=root;
        BSTNode* q;        
        while(p!=0) {
          q=p;
          if(x<(*p).value) p=(*p).left;
          else if(x>(*p).value) p=(*p).right;        
          else return;
        }
        if(x<(*q).value) (*q).left=new BSTNode(x);
        if(x>(*q).value) (*q).right=new BSTNode(x);                
    }
    int find(float x) {
        if(root==0) return 0;
        BSTNode* p=root;
        while(p!=0) {
          if(x<(*p).value) p=(*p).left;
          else if(x>(*p).value) p=(*p).right;        
          else return 1;
        }
        return 0;
    }
/*
    void remove(float x) {    
    }
*/    
    float findMin() {
        if(root==0) throw Exception("EmptyTreeException");
        BSTNode* p=root;
        BSTNode* q;        
        while(p!=0) {
           q=p;
           p=(*p).left;
        }
        return (*q).value;
    }
    float findMax() {
        if(root==0) throw Exception("EmptyTreeException");
        BSTNode* p=root;
        BSTNode* q;        
        while(p!=0) {
           q=p;
           p=(*p).right;
        }
        return (*q).value;

    }
    
    void printTree() {
        recursivePrintTree(root);                
    }

    void InorderPrintTree() {
        recursiveInorderPrintTree(root);                
    }
};

int test_bst() {

  BSTree t;
  t.insertValue(10);
  t.insertValue(5);  
  t.insertValue(12);  
  t.insertValue(3);  
  t.insertValue(15);      
  t.insertValue(13);        
  t.insertValue(6);  
  t.insertValue(4);  
  
  BSTree z;
  
  z=t;  
  t.printTree();
  z.printTree();

  cout << "The minimum is " << z.findMin() << endl;
  cout << "The maxmimum is " << z.findMax() << endl;
  for(int i=0; i<20; i++) 
    if(z.find(i)) cout << "I found " << i << " in the tree\n";
  
  return 0;
}
