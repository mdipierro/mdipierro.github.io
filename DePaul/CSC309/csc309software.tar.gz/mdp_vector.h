/////////////////////////////////
// FILE: mdp_vector.h
// Written by Massimo Di Pierro
/////////////////////////////////
/*
--------------------------
     Method Summary
--------------------------
void resize(int i)  //resize the vector to i.
int length() const  //return the length of the vector

*/


// Generic class Vector of T, where T can be any type of object

template<class T>
class Vector {
private:
  T* m;
  int size;
public:
  // constructor

  Vector() {
    this->size=0;
    if(size>0) m=new T[0];
  }


  Vector(int size) {
    this->size=size;
    if(size>0) m=new T[size];
  }

  // destructor

  ~Vector() {
    if(size>0) delete[] m;
  }

  // copy constructor
  
  Vector(const Vector& a) {
    size=a.size;
    if(size>0) m=new T[size];
    for(int i=0; i<size; i++) m[i]=a.m[i];
  }

  // assignment operator

  Vector& operator=(const Vector& a) {
    if(&a==this) return *this;
    if(size>0) delete[] m;
    size=a.size;
    if(size>0) m=new T[size];
    for(int i=0; i<size; i++) m[i]=a.m[i];
    return *this;
  }

  // get vector length

  int length() const { 
    return size; 
  }

  // get minimum between a and b

  static int min(int a, int b) {
    if(a<b) return a;
    return b;
  }

  // resize vector

  void resize(int size) {
    T* new_m;
    if(size>0) new_m=new T[size];    
    for(int i=0; i<min(size,this->size); i++) new_m[i]=m[i];
    if(this->size>0) delete[] m;
    this->size=size;
    m=new_m;
  }

  // append an element at the end

  void push_back(T a) {
    resize(length()+1);
    (*this)[length()-1]=a;
  }

  // insert an element at the beginning

  void push_front(T a) {
    resize(length()+1);
    for(int i=length()-2; i>=0; i--) (*this)[i+1]=(*this)[i];
    (*this)[0]=a;
  }

  // remove and return the last element

  T pop_back() {
    T x=(*this)[length()-1];
    resize(length()-1);
    return x;
  }

  // remove and return the first element

  T pop_front() {
    T x=(*this)[0];
    for(int i=0; i<length()-2; i++) (*this)[i]=(*this)[i+1];
    resize(length()-1);
    return x;
  }


  T&  operator[] (int i) {
    if(i<0 || i>=length()) throw Exception("VectorOutOfBounds");
    return m[i];
  }

  const T&  operator[] (int i) const {
    if(i<0 || i>=length()) throw Exception("VectorOutOfBounds");
    return m[i];
  }

  friend ostream& operator<< (ostream& os, const Vector& v) {
    os << "(";
    for(int i=0; i<v.length(); i++) 
      if(i==0) 
	os << "\"" << v[i] << "\"";
      else
	os << "," << "\"" << v[i] << "\"";
    os << ")";
    return os;
  }
};

// Return true if Vector a and Vector b are equal (contain same elements), false otherwise

template<class T>
bool operator==(const Vector<T>& a, const Vector<T>& b) {
  if(a.length()!=b.length()) return false;
  for(int i=0; i<a.length(); i++) if(a[i]!=b[i]) return false;
  return true;
}

// Return true if Vector a and Vector b are not equal (contain same elements), false otherwise

template<class T>
bool operator!=(const Vector<T>& a, const Vector<T>& b) {
  return !(a==b);
}

