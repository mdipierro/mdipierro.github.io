// /////////////////////////////
// FILE: mdp_replace_string.h
// Written by Massimo Di Pierro
// /////////////////////////////

void replace_string() {
  int i,j,k;
  String in, out, filename, line;
  List<String> a;
  ifstream file;
  cout << "Insert a file name   :"; cin >> filename;
  cout << "String to be replaced:"; cin >> in;
  cout << "To be replaced with  :"; cin >> out;
  file.open(filename.c_str());
  while(true) {
    file >> line; if(file.fail()) break;
    a.append(line);    
  }
  for(i=0; i<a.length(); i++) {
    for(k=0; 
        k<a[i].length() && (j=a[i].find(in,k))>=0; 
        k=k+j+out.length()) 
        a[i]=a[i].replace(j,in.length(),out);
    cout << a[i] << endl;
  }
  file.close();
}


