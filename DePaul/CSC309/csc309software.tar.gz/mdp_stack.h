// ///////////////////////////
// FILE: mdp_stack.h
// ///////////////////////////
/*
--------------------------
     Method Summary
--------------------------
bool isEmpty()  //return true if the stack is empty.
bool isFull()  //return true if the stack is full.
void push(int n)  //push integer n onto the stack.
int pop()  //pop an integer from the stack.
*/


// A class Stack of integers (int* arr)

class Stack {
private:
  int  MaxStack;
  int  top; // pointer within the stack
  int* arr; // stack container

public:
  // Constructor (by default i=5 for example)

  Stack(int i) {
    arr=new int[MaxStack=i];
    top=-1;
  }
  
  // Destructor

  virtual ~Stack() {
    delete[] arr;
  }

  // Copy Constructor

  Stack(const Stack& s) {
    top=s.top;
    MaxStack=s.MaxStack;
    arr=new int[MaxStack];
    for(int i=0; i<MaxStack; i++) arr[i]=s.arr[i];
  }

  // Assignment operator

  Stack& operator=(const Stack& s) {
    delete[] arr;
    top=s.top;
    MaxStack=s.MaxStack;
    arr=new int[MaxStack];
    for(int i=0; i<MaxStack; i++) arr[i]=s.arr[i];
    return *this;
  }

  // Check is stack is empty
  
  bool isEmpty() const { return top < 0; }

  // Check is stack is full
  
  bool Stack::isFull() const  { return top == MaxStack-1; }
  
  // push (=put) a number n into the array
  
  void push(int n) {
    if(isFull()) throw Exception("StackFullException");
    arr[++top]=n;
  }

  // pop (=retrieve) the last number pushed into the stack

  int pop() {
    if(isEmpty()) throw Exception("StackEmptyException");
    return arr[top--];
  }

  friend ostream& operator<<(ostream& os, const Stack& s) {
    if(s.isEmpty()) os << "[]";
    else {
      os << "[";
      for(int i=s.top; i>=0; i--)
	os << i << ":" << s.arr[i] << " ";
      os << "]";
    }
    return os;
  }
  
  friend bool operator==(const Stack& a, const Stack& b) {
    if(a.MaxStack != b.MaxStack) return false;
    if(a.top != b.top) return false;
    for(int i = a.top; i >= 0; i--)
      if(a.arr[i] != b.arr[i])
	return false;
    return true;
  }
  
  friend bool operator!=(const Stack& a, const Stack& b) {
    return !(a==b);
    }

}; // end class



