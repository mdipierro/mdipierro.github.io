// ///////////////////////////
// FILE: scaffolding.h
// Written by Massimo Di Pierro
// ///////////////////////////

// Tip: place this at the top of any program

class __scaffolding__class  {
public:
  ~__scaffolding__class() {
    cout << "press ENTER to continue...\n";
    if(cin.peek()=='\n') cin.ignore(1,'\n');
    cin.get();
  }
} __scaffolding__;


