#include "mdp_all.h"


int main() {
  test_bst();
  system("PAUSE");
  return 0;
}
