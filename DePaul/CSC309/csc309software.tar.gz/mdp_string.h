// ///////////////////////////
// FILE: mdp_string.h
// Written by Massimo Di Pierro
// ///////////////////////////
/*
--------------------------
     Method Summary
--------------------------
char* c_str() const  //return the c-style string.
int length() const  //return the length of the string.
void resize(int i)  //resize the string to the specified size.
String erase(int i, int j) //return the string with j characters removed, starting at index i.
String insert(int i, String q) //return the string that has been inserted with String q at index i. 
String replace(int i, int j, String q) //return the string with j characters replaced, starting at index i, by String q
String substr(int i, int j);  //return a sub-string of size j, starting at index i.
int find(String q, int i);  //Look for sub-string q, starting at position i. And
                            //return an int corresponding to where that sub-string starts, or -1
                            //if it can't find that sub-string
int toInt();  //convert the string to the corresponding integer and return it.
float toFloat();  //convert the string to the corresponding float and return it.
*/


// Example of class String (similar to the C++ class sting)

class String {
 private:
  char* s;
  int size;
 public:

// Constructor (set the String to an empty String null terminated)

  String() {
    s=new char[size=1];
    s[0]='\0';
  }
  
  // Destructor (deallocate the String)
  
  ~String() {
    if(s!=0) delete[] s;
  }
  
  // Resize a String and null terminate it
  
  void resize(int i) {
    if(s!=0) delete[] s;
    s=new char[size=i+1];
    memset(s,0,size);
  }
  
  // Return the length of the sting (not counting the termination character �\0�)
  
  int length() const {
    return size-1;
  }

  // Copy constructor (note const and passing by reference!)
  
  String (const String& p) {
    size=0; s=0;
    resize(p.length());
    strcpy(s,p.s);
  }
  
  // Conversion constructor
  
  String (const char* p) {
    size=0; s=0;
    resize(strlen(p));
    strcpy(s,p);
  }

  // Other constructor (make a String of n characters all equal to c)
  
  String(int n, char c) {
    size=0; s=0;
    resize(n);
    for(int i=0; i<n; i++) s[i]=c;
    s[n]='\0';
  }
  
  // Assignment operator (note const and passing by reference)
  
  String& operator= (const String& p) {
    resize(p.length());
    strcpy(s,p.s);
    return *this;
  }
  
  // Conversion Assignment
  
  String& operator= (char* p) {
    resize(strlen(p));
    strcpy(s,p);
    return *this;
  }
  
  // Return the corresponding C-String
  
  char* c_str() const {
    return s;
  }
  
  // operator[] to access individual characters of the String
  
  char& operator[](int i) {
    if(i<0 || i>=size) throw Exception("StringIndexOutOfBoundsException");
    return s[i];
  }

  // operator[] to access individual characters of the String in const functions
  
  const char& operator[](int i) const {
    if(i<0 || i>=size) throw Exception("StringIndexOutOfBoundsException");
    return s[i];
  }

  // Erase j characters from the String starting at position i
  
  String erase(int i, int j) {
    if(i<0 || i>=size || j<0 || i+j>=size) 
      throw Exception("StringIndexOutOfBoundsException");
    int k;
    int sl=length();
    String tmp(sl-j,'x');
    for(k=0; k<i; k++) tmp[k]=s[k];
    for(k=i+j; k<sl; k++) tmp[k-j]=s[k];
    return tmp;
  }
  
  // Insert String q in the String at position i
  
  String insert(int i, String q){
    if(i<0 || i>=size) 
      throw Exception("StringIndexOutOfBoundsException");
    int k;
    int sl=length();
    int ql=q.length();
    String tmp(sl+ql,' ');
    for(k=0; k<i; k++) tmp[k]=s[k];
    for(k=i; k<i+ql; k++) tmp[k]=q[k-i];
    for(k=i+ql; k<sl+ql; k++) tmp[k]=s[k-ql];
    return tmp;
  }

  // Replace the j characters of the String (starting at position i) with the String q
  
  String replace(int i, int j, String a){
  return erase(i,j).insert(i,a);
  };
  
  // Return a subString of the String consisting of the j characters starting at position i
  
  String substr(int i, int j){
    if(i<0 || i>=size || j<0 || i+j>=size) 
      throw Exception("StringIndexOutOfBoundsException");
    int k;
    String tmp(j,' ');
    for(k=i; k<i+j; k++) tmp[k-i]=s[k];
    return tmp;
  }

  // look if q is a sub-String of String starting at position i or after. If so return the position where the sub-String 
  // starts, else retrun �1.
  
  int find(String q, int i){
    if(i<0 || i>=size) 
      throw Exception("StringIndexOutOfBoundsException");
    int j,k;
    int ql=q.length();
    int dl=length()-ql+1;
    for(j=i; j<dl; j++) {
      for(k=0; k<ql; k++) if(s[j+k]!=q[k]) break;
      if(k==ql) return j;
    }
    return -1;
  }

  // Convert String to integer
  
  int toInt() {
    return atoi(c_str());
  }

  // Convert String to float
  
  float toFloat() {
    return atof(c_str());
  }
};

// Concatenates String a with String b and return the concatenated String

String operator+(const String& a, const String& b) {
  String c;
  c.resize(a.length()+b.length());
  strcpy(c.c_str(),a.c_str());
  strcat(c.c_str(),b.c_str());
  return c;
}

// Concatenate String a with the character b and return the concatenated String

String operator+(const String& a, char b) {
  String c;
  c.resize(a.length()+1);
  strcpy(c.c_str(),a.c_str());
  c[a.length()]=b;
  return c;
}

// Retrun true if a is equal b, false otherwise

bool operator==(const String& a, const String& b) {
  if(strcmp(a.c_str(),b.c_str())==0)
    return true;
  return false;
}

// Retrun true if a is not equal b, false otherwise

bool operator!=(const String& a, const String& b) {
  if(strcmp(a.c_str(),b.c_str())==0)
    return false;
  return true;
}

// Retrun true if a is less than b, false otherwise (according with strcmp)

bool operator<(const String& a, 
               const String& b) {
  return(strcmp(a.c_str(),b.c_str())<0);
}

// Retrun true if a is bigger than b, false otherwise (according with strcmp)

bool operator>(const String& a, 
               const String& b) {
  return(strcmp(a.c_str(),b.c_str())>0);
}

// Retrun true if a is less or equal than b, false otherwise (according with strcmp)

bool operator<=(const String& a, 
               const String& b) {
  return(strcmp(a.c_str(),b.c_str())<=0);
}

// Retrun true if a is bigger or equal than b, false otherwise (according with strcmp)

bool operator>=(const String& a, 
               const String& b) {
  return(strcmp(a.c_str(),b.c_str())>=0);
}

// Send the String to the output stream os

ostream& operator<<(ostream& os, const String& p) {
  os << p.c_str();
  return os;
}

// Reads a String from the input stream is 
// !!! this function differs from standard C++ definition !!!

istream& operator>>(istream& is, String& s) {
  char c;
  s="";
  while(true) {
    c=is.get();
    if(c=='\n') break;
    s=s+c;
  }
  return is;
}

