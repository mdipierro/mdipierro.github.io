/////////////////////////////////
// FILE: mdp_queue.h
// Written by Massimo Di Pierro
/////////////////////////////////
/*
--------------------------
     Method Summary
--------------------------
void enque(int x) //insert integer x into the queue.
int deque() //remove the first integer in the queue.

*/

class Queue {
private:
    int* data;
    int  size;
    int  counter1;
    int  counter2;
    int  nelem;
public:
    Queue(int s) {
        data=new int[s];
        size=s;
        counter1=0;
        counter2=0;
        nelem=0;
    }
    ~Queue() {
        if(size>0) delete[] data;
    }
    Queue(const Queue& a) {
        size=a.size;               
        data=new int[size];
        for(int i=0; i<size; i++) data[i]=a.data[i];
        counter1=a.counter1;     
        counter2=a.counter2;
        nelem=a.nelem;
    }
    Queue& operator=(const Queue& a) {
        if(&a==this) return (*this);
        if(size>0) delete[] data;
        size=a.size;               
        data=new int[size];
        for(int i=0; i<size; i++) data[i]=a.data[i];
        counter1=a.counter1;
        counter2=a.counter2;
        nelem=a.nelem;
        return (*this);
    }
    void enque(int x) {
        if(nelem==size) throw Exception("Overflow");
        data[counter1]=x;
        counter1=(counter1+1) % size;
        nelem++;       
        // store x into data
    }    
    int deque() {
        int x;
        if(nelem==0) throw Exception("Underflow");
        x=data[counter2];
        counter2=(counter2+1) % size;
        nelem--;
        // get x from data
        return x;
    }
    friend ostream& operator<<(ostream& os, const Queue& a)
    {
        os << "[ ";
        int index = a.counter2;
        for(int i = 0; i < a.nelem; i++)
        {
            index = index % a.size;
            os << a.data[index] << " ";
            index++;
        }
        os << "]";
        return os;
    }

    friend bool operator==(const Queue& a, const Queue& b)
    {
        if(a.counter1 != b.counter1) return false;
        if(a.counter2 != b.counter2) return false;
        int index;
        for(int i = 0; i < a.nelem; i++)
        {
            index = index % a.size;
            if(a.data[index] != b.data[index])
                return false;
            index++;
        }
        return true;
    }    
    friend bool operator!=(const Queue& a, const Queue&b)
    {
        return !(a == b);
    }
};


