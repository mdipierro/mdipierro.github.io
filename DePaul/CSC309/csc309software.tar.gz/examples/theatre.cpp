// Class: CSC_309_501
// Assignment: 2 (Solution)
// Instructor: Massimo Di Pierro

#include "iostream"
#include "string"
using namespace std;

// Note that I use the following conventions:
//   0<=r<rows and row=r+1
//   0<=c<cols and col=c+1
//   r and c are used inside Theatre
//   row and col are used in the class interface
//
// Different conventions are accepted as long as they are consistent!

class Theatre {
private:

  // member variables
  int rows, cols;
  double* prices; // array of row prices
  char*   seats;  // array of seats
public:

  // constructor
  Theatre(int n, int m) {
    // check arguments and eventually throw exception
    if(n<1 || m<1) throw string("Theatre::NoSeatsExcpetion");
    // setup member variables and allocate arrays
    rows=n;
    cols=m;
    prices=new double[rows];
    seats=new char[rows*cols];
    // initialize array
    int r, c;
    for(r=0; r<rows; r++)
      for(c=0; c<cols; c++) 
	seats[r*cols+c]='.';
  }

  // dsetructor
  ~Theatre() {
    delete[] prices;
    delete[] seats;
  }

  // copy constuctor
  Theatre(const Theatre& a) {
    int i;
    rows=a.rows;
    cols=a.cols;
    prices=new double[rows];
    seats=new char[rows*cols];
    for(i=0; i<rows*cols; i++) 
      seats[i]=a.seats[i];
    for(i=0; i<rows; i++) 
      prices[i]=a.prices[i];
    
  }

  // assignment operator
  Theatre& operator=(const Theatre& a) {
    if(&a==this) return (*this);
    int i;
    delete[] prices;
    delete[] seats;
    rows=a.rows;
    cols=a.cols;
    prices=new double[rows];
    seats=new char[rows*cols];
    for(i=0; i<rows*cols; i++) 
      seats[i]=a.seats[i];
    for(i=0; i<rows; i++) 
      prices[i]=a.prices[i];
    return (*this);
  }

   // other methods
   bool reserveSeat(int row, int col) {
     if(row<1 || row>rows) throw("reserveSeat::RowOutOfBoundException");
     if(col<1 || col>cols) throw("reserveSeat::ColOutOfBoundException");
     int r=row-1;
     int c=col-1;
     int i=r*cols+c;
     if(seats[i]=='X') return false;
     seats[i]='X';
     return true;
   }
   int getRows() const {
     return rows;
   }
   int getCols() const {
     return cols;
   }
  void setRowPrice(int row, double price) {
    if(row<1 || row>rows) throw("setRowPrice::RowOutOfBoundException");
    int r=row-1;
    prices[r]=price;
  }
  double getRowPrice(int row) const {
    if(row<1 || row>rows) throw("getRowPrice::RowOutOfBoundException");
    int r=row-1;
    return prices[r];
  }
  void showSeats() const {
    int r,c;
     cout << "\nTheatre chart\n\n";
     for(c=0; c<cols; c++)
       cout << (c + 1) % cols;
     cout << endl;
     for(r=0; r<rows; r++) {
       for(c=0; c<cols; c++)
	 cout << seats[r*cols+c];
       cout << " row " << r+1 << "($" << prices[r] << ")\n";
     }
   }
   double showIncome() const {
     int r,c;
     double income=0;
     for(r=0; r<rows; r++) 
       for(c=0; c<cols; c++)
	 if(seats[r*cols+c]=='X') income+=prices[r];
     return income;
   }
};

void queryRowPrices(Theatre& theatre) {
  double price;
  for(int row=1; row<=theatre.getRows(); row++) {
    cout << "price for row n." << row << " = $";
    cin >> price;
    theatre.setRowPrice(row,price);
  }
}

void enterMainMenu(Theatre& theatre) {
  int option, row, col;
  do {
    cout << "--------------------------------\n";
    cout << "Main Menu\n";
    cout << "--------------------------------\n";
    cout << "0) Exit\n";
    cout << "1) Show Available Seats\n";
    cout << "2) Show Income\n";
    cout << "3) Reserve Seat\n";
    cout << "--------------------------------\n";
    cin >> option;
    switch(option) {
    case 0:
      cout << "Bye..."; 
      break;
    case 1:      
      theatre.showSeats();
      break;
    case 2:
      cout << "\nTheatre income = $" << theatre.showIncome() << "\n\n";
      break;
    case 3:
      theatre.showSeats();
      cout << "Reserve a seat\n";
      cout << "row ="; cin >> row;
      cout << "col ="; cin >> col;
      if(row<1 || row>theatre.getRows() || 
	 col<1 || col>theatre.getCols()) 
	cout << "The seat does not exist!\n\n";
      else if(theatre.reserveSeat(row,col)) 
	cout << "Reserved!\n\n";
      else
	cout << "Seat already taken!\n\n";
      break;
    }
  } while (option!=0);
}

int main() {
  int rows, cols;

  try {

    do {
      cout << "Theatre rows = "; cin >> rows;
      cout << "Theatre cols = "; cin >> cols;
      if(rows<=0 || cols<=0) cout << "Incorrect theatre size\n";
    } while(rows<=0 || cols<=0);
    
    Theatre theatre(rows, cols);
    queryRowPrices(theatre);
    enterMainMenu(theatre);

  } catch(string exception) {
    cout << "FATAL EXCEPTION:\n" << exception << endl;
  }

  return 0;
}
