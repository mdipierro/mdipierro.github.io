// ///////////////////////////
// FILE: test_quote.cpp
// ///////////////////////////

#include "mdp_all.h"

/* do not modify class Quote ... use it */

class Quote {
public:
  int day;        // day of trade
  int month;      // month of trade
  int year;       // year of trade
  float open;     // opening price
  float high;     // highest price of the day
  float low;      // lowest price of the day
  float close;    // closing price of the day
  float adjClose; // closing price corrected for dividends
  long volume;
  Quote(int day0=0, int month0=0, int year0=0, 
	float open0=0, float high0=0, float low0=0, float close0=0, 
	float adjClose0=0, long volume0=0) {
    day=day0;   
    month=month0; 
    year=year0;
    open=open0; 
    high=high0; 
    low=low0; 
    close=close0;
    adjClose=adjClose0;
    volume=volume0; 
  }
};


Quote parseQuote(String s) {
    // NO NEED TO UNDERSTAND THIS FUNCTION
    int i;
    static const String months[12]={"Jan", "Feb", "Mar", "Apr", "May", "Jun", 
				    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    Quote quote;
    char buffer[16];
    sscanf(s.c_str(),"%d-%[^-]-%d,%f,%f,%f,%f,%ld,%f", 
	   &(quote.day), buffer, &(quote.year),
	   &(quote.open), &(quote.high), &(quote.low), &(quote.close),
	   &(quote.volume), &(quote.adjClose));
    if(quote.year<20) quote.year+=2000; else quote.year+=1900;
    for(i=0; i<12; i++) if(months[i]==buffer) break;
    if(i>12) throw String("reading failure");
    quote.month=i+1;
    return quote;
}


void printAllQuotes(String stock) {
  ifstream ifile;
  String a;
  Quote quote;

  stock=stock+".dat";
  ifile.open(stock.c_str());
  if(!ifile) {
	cerr << "Unable to open file\n";
	return;
  }
  while(!ifile.eof()) {
    ifile >> a;
    quote=parseQuote(a);
    cout << quote.month << "/"
	 << quote.day << "/"
	 << quote.year << " closed at "
	 << quote.adjClose << endl;
  }
}

// PROBLEM 1 ... complete this funcction

ostream& operator<<(ostream& os, const Quote& s) {
    os << "Date:" << s.month << "/" << s.day << "/" << s.year << endl;
    os << "adjClose:" << s.adjClose << endl;
    os << "high:" << s.high << endl;
  return os;
}

int countFileLines(String filename) {
  int size=0;
  String a;
  ifstream ifile;
  ifile.open(filename.c_str());
  if(!ifile) {
	cerr << "Unable to open file\n";
        return 0;
  }
  while(!ifile.eof()) {
    ifile >> a;
    size++;
  }
  ifile.close();
  return size-1;
}

void readQuotesFromFile(String filename, Quote* data, int size) {
  String a;
  int i=0;
  ifstream ifile;
  ifile.open(filename.c_str());
  if(!ifile) {
     cerr << "Unable to open file\n";
     throw String("Unable to open file");
  }
  for(i=0; i<size; i++) {
    ifile >> a;
    data[i]=parseQuote(a);
  }
  ifile.close();
}

// PROBLEM 2: write copy constructor and assignment operator for 
// class StockQuotes
// (would be nice if you also make member variables private and 
// write methods to get them).
// PROBLEM 3: write the other methods as described in the assignment.

class StockQuotes {
public:
  Quote* data;
  int size;
  StockQuotes(String stock) {
    size=0;
    stock=stock+".dat";

    // measure the file size;
    size=countFileLines(stock);
      
    // allocate memory
    data=new Quote[size];

    // read the data...
    readQuotesFromFile(stock, data, size);
  }
  ~StockQuotes() {
    // fill here ...
    if(size>0) delete[] data;
  }

  // you write the copy constructor (problem 2)
  StockQuotes(const StockQuotes& a) {
    size=a.size;
    if(size>0) data=new Quote[size];
    for(int i=0; i<size; i++) data[i]=a.data[i];
  }

  // you write the assignment operator (problem 2)
  StockQuotes& operator=(const StockQuotes& a) {
    if(&a==this) return (*this);
    if(size>0) delete[] data;
    size=a.size;
    if(size>0) data=new Quote[size];
    for(int i=0; i<size; i++) data[i]=a.data[i];
    return (*this);
  }

  // your other methods here ... (problem 3)
  Quote maxHigh() {
    int i=0;
    for(int j=1; j<size; j++) 
       if(data[j].high>data[i].high) i=j;
    return data[i];
  }

  Quote maxJump() {
    int i=0;
    for(int j=1; j<size; j++) 
       if(data[j].high-data[j].low>data[i].high-data[i].low) i=j;
    return data[i];
  }

  float volatility(int year) {
      int i;
      int Ndays=0;
      float xbar=0;
      for(i=0; i<size; i++)
         if(data[i].year==year) {
              Ndays++;
              xbar+=data[i].close-data[i].open;
         }
      xbar=xbar/Ndays;
      float xi,sum=0;
      for(i=0; i<size; i++)
         if(data[i].year==year) {
         xi=data[i].close-data[i].open;
              sum+=pow(xi-xbar,2);
         }
      float vol=sqrt(1.0/Ndays*sum);
      return vol;
  }

  int maxVolatility() {
    int minyear=0, maxyear=0;
    for(int i=1; i<size;i++) {
        if(data[i].year<data[minyear].year) minyear=i;
        if(data[i].year>data[maxyear].year) maxyear=i;
    }
    minyear=data[minyear].year;
    maxyear=data[maxyear].year;    
    float v, vol;
    int year0;
    for(int year=minyear; year<maxyear+1; year++) {
        v=volatility(year);
        if(v>vol) { vol=v; year0=year; }
    }
    return year0;    
  }

  void printDayDividends() {
    float dividend;
    for(int i=1; i<size; i++) {        
        dividend=(data[i].close-data[i].adjClose)-(data[i-1].close-data[i-1].adjClose);
        if(dividend>0.001) cout << data[i].month << "/" << data[i].day << "/" << data[i].year << " " << dividend << endl;
    }
  }

}; // end class


// PROBLEM 4: edit main ...
// (this is just an example that reads the quotes from file and 
// prints all closing prices.)

int main() {

  StockQuotes intc("intc");
  Quote quote=intc.maxHigh();
  cout << quote.month << "/" << quote.day << "/" << quote.year << endl;
  cout << intc.maxVolatility() << endl;
  
  intc.printDayDividends();
  system("PAUSE");
  return 0;
}
