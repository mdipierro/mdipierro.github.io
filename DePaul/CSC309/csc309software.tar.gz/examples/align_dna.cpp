#include "mdp_all.h"

// FUNCTION PROVIDED
// NO NEED TO UNDERSTAND HOW THIS WORKS INSIDE
int DNA_Align(String a, String b) {
  int* line0=new int[b.length()+1];
  int* line1=new int[b.length()+1];
  int i,j;
  for(i=0; i<b.length()+1; i++) line0[i]=0;
  for(j=0; j<a.length(); j++) {
    line1[0]=0;
    for(i=0; i<b.length(); i++) {
      if(a[j]==b[i]) line1[i+1]=line0[i]+1;
      else if(line1[i]>line0[i+1]) line1[i+1]=line1[i];
      else line1[i+1]=line0[i+1];
    }
    for(i=0; i<b.length()+1; i++) line0[i]=line1[i];      
  }
  int ret=line0[b.length()];
  delete[] line1;
  delete[] line0;
  return ret;
}

class Virus {
public:
  String name;
  String dna;  
};

class Pair {
public:
  String virus_name1, virus_name2;
  int alignment;
};

// PROBLEM 1

Vector<Virus> readViruses(String filename) {
  Vector<Virus> viruses;
  int size;
  ifstream input;
  input.open(filename.c_str());
  if(!input) {
     throw Exception("Unable to open file");
  }
  input >> size;
  cout << viruses.length() << endl;
  for(int i=0; i<size; i++) {
     input >> viruses[i].name;
     input >> viruses[i].dna;
  }
  input.close();
  return viruses;
}

// PROBLEM 2

Vector<Pair> alignViruses(const Vector<Virus>& viruses) {
  Vector<Pair> pairs;
  int i,j,k;
  int size=viruses.length();
  pairs.resize(size*(size-1)/2);
  k=0;
  for(i=0; i<viruses.length()-1; i++)
    for(j=i+1; j<viruses.length(); j++) {
      pairs[k].virus_name1=viruses[i].name;
      pairs[k].virus_name2=viruses[j].name;
      pairs[k].alignment=DNA_Align(viruses[i].dna,viruses[j].dna);
      k++;
    }    
  return pairs;
}

// PROBLEM 3

void sortPairs(Vector<Pair>& pairs) {
  int i,j;
  Pair tmp;
  for(i=1; i<pairs.length(); i++)
    for(j=i; j>0; j--) 
      if(pairs[j].alignment<pairs[j-1].alignment)
        { tmp=pairs[j]; pairs[j]=pairs[j-1]; pairs[j-1]=tmp; }
      else
        break;
}

// PROBLEM 4

ostream& operator<< (ostream& os, const Virus& virus) {
  os << "Name=" << virus.name << ",DNA=" << virus.dna << endl;
  return os;
}
ostream& operator<< (ostream& os, const Pair& pair) {
  os << pair.alignment << " for names=" << pair.virus_name1 << "," << 
pair.virus_name2 << endl;
  return os;
}

int main() {
  try {
    Vector<Virus> viruses_table;
    Vector<Pair> viruses_pairs;  
    viruses_table=readViruses("hiv.dat");    
    cout << viruses_table << endl;
    viruses_pairs=alignViruses(viruses_table);
    sortPairs(viruses_pairs);
    cout << viruses_pairs << endl;
  } catch(Exception e) {
    cout << "Excetpion: " << e.value() << endl;
  }
  return 0;
}

