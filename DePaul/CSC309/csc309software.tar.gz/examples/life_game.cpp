#include "mdp_all.h"

class Board : private Vector<int> {
private:
  int rows, cols;
public:
  Board(int i, int j) {
    // excpetions ...
    rows=i;
    cols=j;
    resize(i*j);
  }
  int getCols() const {
    return cols;
  }
  int getRows() const {
    return cols;
  }
  int& operator() (int i, int j) {
    i=(i+rows) % rows;
    j=(j+cols) % cols;
    return (*this)[i*cols+j];
  }
  const int& operator() (int i, int j) const {
    i=(i+rows) % rows;
    j=(j+cols) % cols;    
    return (*this)[i*cols+j];
  }
};

void init(Board& board) {
  int i, j;
  for(i=0; i<board.getRows(); i++)
    for(j=0; j<board.getCols(); j++)
      board(i,j)=rand() %2;
  }

int sum_neighbors(Board& board, int i, int j) {
  int sum=board(i-1,j-1)+
    board(i,j-1)+
    board(i+1,j-1)+
    board(i-1,j)+
      board(i+1,j)+
    board(i-1,j+1)+
    board(i,j+1)+
    board(i+1,j+1);
  return sum;
}

void play(Board &board) {
  Board c=board;
  int i,j, sum;
  for(i=0; i<board.getRows(); i++)
    for(j=0; j<board.getCols(); j++) {
      sum=sum_neighbors(board,i,j);
      if (board(i,j)==0) {
	if(sum==3) c(i,j)=1; // birth
	else       c(i,j)=0;
      } else if (board(i,j)==1) {
	if(sum<2 || sum>3) c(i,j)=0; // death
	else               c(i,j)=1; // survival
      }
    }
  board=c;
}

void draw(Board& board) {
  int i,j;
  for(i=0; i<board.getRows(); i++) {
    for(j=0; j<board.getCols();  j++) cout << board(i,j);
    cout << endl;
  }
}

int main() {
  int n,m,selection;
  srand(clock());
  cout << "Number of rows:"; cin >> n;
  cout << "Number of cols:"; cin >> m;
  Board board(n,m);
  init(board);

  while(1) {
    play(board);
    draw(board);
    cout << "Press [0]+[enter] to continue, [1]+[enter] to exit...";
    cin >> selection;
    if(selection) break;
  }
  return 0;
}

