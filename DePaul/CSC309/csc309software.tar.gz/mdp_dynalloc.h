// ///////////////////////////
// FILE: mdp_dynalloc.h
// Written by Massimo Di Pierro
// ///////////////////////////

// Tip: place this at the top of any program to debug memory allocation problems

#include "malloc.h"

void* operator new(size_t size) {
  cout << "allocating " << size << " bytes";
  void *p=malloc(size);
  cout << " at " << p << endl;
  return p;
}

void operator delete (void* pointer) {
  cout << "dellocating from " << pointer << endl;
  free(pointer); 
}

void* operator new[] (size_t size) {
  cout << "allocating " << size << " bytes";
  void *p=malloc(size);
  cout << " at " << p << endl;
  return p;
}

void operator delete[] (void* pointer) {
  cout << "dellocating from " << pointer << endl;
  free(pointer); 
}

