#!/usr/bin/env python
# coding: utf8
from gluon import *

CLIENT_ID="test"
CLIENT_SECRET="test"
