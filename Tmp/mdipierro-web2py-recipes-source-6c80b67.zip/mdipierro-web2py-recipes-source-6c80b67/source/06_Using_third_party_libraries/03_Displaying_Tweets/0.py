# coding: utf8

TWITTER_HASH = "web2py"
