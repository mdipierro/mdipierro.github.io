# -*- coding: utf-8 -*-

db.define_table("mytable",
     Field("name","string"),
     Field("salary","integer"),
)
