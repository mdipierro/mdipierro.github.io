# coding: utf8
# intente algo como
def index(): return dict(message="hello from BasicJSONRPC.py")

def index():
    response.view = "BasicJSONRPC.html"
    return dict()

def BasicJSONRPC():
    response.view = "BasicJSONRPC.html"
    return dict()
