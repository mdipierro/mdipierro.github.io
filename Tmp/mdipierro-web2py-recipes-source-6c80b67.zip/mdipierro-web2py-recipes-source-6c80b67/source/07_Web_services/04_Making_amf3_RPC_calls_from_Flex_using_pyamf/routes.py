# -*- coding: utf-8 -*-
routes_in = (('/crossdomain.xml', '/app/static/crossdomain.xml'),)
