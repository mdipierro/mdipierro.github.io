# coding: utf8

db.define_table('mytable',
    Field('name'),
    Field('quantity','integer'))
