# coding: utf8
# intente algo como
def index(): return dict(message="hello from legacy.py")

def page(): return dict()
