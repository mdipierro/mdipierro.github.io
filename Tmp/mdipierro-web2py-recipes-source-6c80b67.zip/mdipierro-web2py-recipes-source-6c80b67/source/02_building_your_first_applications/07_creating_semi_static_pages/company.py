# coding: utf8
# intente algo como
def index(): return dict(message="hello from company.py")

def about_us(): return flatpage()
def mision_vision(): return flatpage()
def our_team(): return flatpage()
