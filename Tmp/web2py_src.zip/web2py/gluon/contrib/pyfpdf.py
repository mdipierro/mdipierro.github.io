#!/usr/bin/env python
# -*- coding: utf-8 -*-

"FPDF for python (a.k.a. pyfpdf)"
# Read more about this http://code.google.com/p/pyfpdf
# Please note that new package name is fpdf (to avoid some naming conflicts)
# import fpdf into pyfpdf for backward compatibility (prior web2py 2.0):
from fpdf import *

# import warnings
# warnings.warn("pyfpdf package name is deprecated, please use fpdf instead")
