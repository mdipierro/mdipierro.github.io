import os
from engine import Engine

db.define_table(
    'model',
    Field('name',requires=IS_NOT_IN_DB(db,'model.name')),
    Field('fiscal_year','integer',writable=False),
    Field('description','text'),
    Field('engine','text',writable=False,readable=False),
    Field('changelog','text',writable=False),
    auth.signature,
    format='%(name)s')

if auth.user and not db(db.model).count():
    engine=Engine()
    engine.compute()
    id=db.model.insert(name='demo',fiscal_year=2011,engine=engine.serialize())

def load_engine():
    return Engine(db.model[session.model['id']].engine)

def save_engine(engine, id=None):
    db.model[id or session.model['id']].update_record(
        engine=engine.serialize())

def comp(a,b):
    for x,y in (('ugrd','aaa'),('grad','bbb'),('total','zzz'),
                ('full','aaa'),('part','bbb'),('abroad','ta')):
        a=a.replace(x,y)
        b=b.replace(x,y)
    return cmp(a,b)
