# -*- coding: utf-8 -*-
# this file is released under public domain and you can use without limitations
#########################################################################
## Customize your APP title, subtitle and menus here
#########################################################################

response.title = T('DePaul Enrollment Projection Calculator')

#http://dev.w3.org/html5/markup/meta.name.html
response.meta.author = 'mdipierro@cs.depaul.edu'
response.meta.description = ''
response.meta.keywords = 'web2py, python, framework'
response.meta.generator = 'Web2py Enterprise Framework'
response.meta.copyright = 'Copyright 2007-2010'

##########################################
## this is the main application menu
## add/remove items as required
##########################################

response.menu = [
    (T('DePaul'), False, 'http://depaul.edu'),
    (T('Projections'), False, URL(request.application,'default','main')),
    (T('About'), False, URL(request.application,'default','about')),
    ]
