# -*- coding: utf-8 -*-

from gluon.tools import *

db = DAL('sqlite://storage.sqlite')            # if not, use SQLite or other DB
mail = Mail()                                  # mailer
auth = Auth(globals(),db)                      # authentication/authorization

mail.settings.server = 'logging' or 'smtp.gmail.com:587'  # your SMTP server
mail.settings.sender = 'you@gmail.com'                    # your email
mail.settings.login = 'username:password'                 # your credentials

auth.settings.hmac_key = 'sha512:216397a4-d804-4e93-b2d8-bdac6a826894'
auth.define_tables()                           # creates all needed tables
auth.settings.mailer = mail                    # for user email verification
auth.settings.registration_requires_verification = False
auth.settings.registration_requires_approval = False

if auth.user and not auth.user.email.lower() in settings.valid_users:
    response.flash='Not authorized'
    auth.logout()

if request.function=='user':
    if request.args(0)=='logout': session.clear()
elif session.auth and db(db.auth_user).isempty(): redirect(URL('user/logout'))
