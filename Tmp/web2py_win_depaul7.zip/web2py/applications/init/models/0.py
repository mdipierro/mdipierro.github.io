from gluon.storage import Storage
settings=Storage()

USERS = ('mdipierro@cs.depaul.edu','ogarduno@depaul.edu','dvaldez@depaul.edu')
MANAGERS = ('mdipierro@cs.depaul.edu',)

settings.host='http://127.0.0.1:8000'
settings.cas_base="https://login.depaul.edu/cas/"
settings.management_roles=['Instructor']
settings.link_color="#336699"
settings.production=False
settings.valid_users= USERS
