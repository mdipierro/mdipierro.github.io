# -*- coding: utf-8 -*-

def index():
    redirect(URL('main'))

def about():
    return dict()

@auth.requires_login()
def change():
    models = db(db.model).select(orderby=~db.model.fiscal_year|db.model.name)
    form=SQLFORM.factory(
        Field('model',
              requires=IS_IN_DB(db,'model.id','%(fiscal_year)s - %(name)s')))
    if form.accepts(request,session):
        session.model = db.model[form.vars.model].as_dict()
        session.flash = 'model selected'
        redirect(URL('main'))
    return dict(form=form)

@auth.requires(auth.user and auth.user.email in MANAGERS)
def create():
    form=SQLFORM(db.model)
    if form.accepts(request,session):
        session.model = db.model[form.vars.id].as_dict()
        try:
            engine=load_engine()
            session.flash = 'model created'
            redirect(URL('main'))
        except RuntimeError, e:
            response.flash = str(e)
    return dict(form=form)

@auth.requires_login()
def clone():
    if not session.model: redirect(URL('change'))
    form = SQLFORM.factory(
        Field('name',requires=IS_NOT_IN_DB(db,'model.name')),
        Field('fiscal_year','integer',default=session.model['fiscal_year']),
        Field('description','text'))
    if form.accepts(request,session):
        engine=load_engine()
        id=db.model.insert(name=form.vars.name,
                           fiscal_year=form.vars.fiscal_year,
                           description=form.vars.description,
                           engine = engine.serialize())
        session.model = db.model(id).as_dict()
        session.flash = 'model cloned'
        redirect(URL('main'))
    return dict(form=form)


@auth.requires(session.model and session.model['created_by']==auth.user_id)
def edit():
    if not session.model: redirect(URL('change'))
    id = request.vars.keys()[0]
    value = request.vars[id]
    items = id[6:].split('_')
    id = '_'.join(items)
    (k,category,year,quarter) = (
        items[0],'/'.join(items[1:-2]),int(items[-2]),items[-1])
    engine=load_engine()
    setattr(engine.data[category][year,quarter],k,int(value))
    data = engine.compute()
    save_engine(engine)
    command =''
    for category, qc in data.items():
        for y,q in qc:
            for k in  ('ns','ts','hchc','hcch','hcrv','ccch','ccrv'):
                key=('%s/%s/%s/%s' % (k,category,y,q)).replace('/','_')
                value = getattr(qc[y,q],k)
                command += "$('#%s').html('%s');" % (key,value)
    command+="$('.flash').html('Saved').show().fadeOut();"
    return command

@auth.requires_login()
def main():
    if not session.model: redirect(URL('change'))
    engine = load_engine()
    if request.vars.new_students:
        if session.model['created_by']==auth.user_id:
            data = engine.compute(int(float(request.vars.new_students)))
            save_engine(engine)
            response.flash="Model recomputed!"
        else:
            response.flash="Not authorized!"
    data=engine.compute_totals()
    return dict(data=data, engine=engine)

@auth.requires_login()
def budgeted():
    if not session.model: redirect(URL('change'))
    engine = load_engine()
    data=engine.compute_totals()
    return dict(data=data, engine=engine)

@auth.requires(session.model and session.model['created_by']==auth.user_id)
def edit_budgeted():
    if not session.model: redirect(URL('change'))
    key,value = request.vars.items()[0]
    items = key.split('_')
    (category,year,quarter,key)=(
        '/'.join(items[:-4]),int(items[-4]),items[-3],'_'.join(items[-2:]))
    engine=load_engine()
    setattr(engine.data[category][year,quarter],key,int(value or 0))
    save_engine(engine)
    return ''

def chart():
    import random
    if not session.model: redirect(URL('change'))
    engine = load_engine()
    data = engine.compute_totals()
    key=request.vars.id
    chdl=request.vars.chdl[:-1]
    categories=chdl.split('|')
    m = 100.0/max(getattr(data[c][y,'total'],key) for y in engine.years for c in categories)
    chd='|'.join(','.join(str(m*getattr(data[c][y,'total'],key)) \
                              for y in engine.years) \
                     for c in categories)
    chxl='0:|%s' % '|'.join(str(y) for y in engine.years)
    chco = ','.join(hex(random.randint(16**5,16**6-1))[2:] for i in categories)
    d=dict(chd=chd,chdl=chdl.replace('/',' '),chxl=chxl,chco=chco)
    url = "http://chart.apis.google.com/chart?cht=lc&chs=600x400&chd=t:%(chd)s&chdl=%(chdl)s&chxt=x&chxl=%(chxl)s&chco=%(chco)s" % d
    return "$('#%(key)s_chart').attr('src','%(url)s');" % dict(key=key,url=url)

@auth.requires_login()
def raw():
    import csv, cStringIO
    s=cStringIO.StringIO()
    writer = csv.writer(s)
    if not session.model: redirect(URL('change'))
    engine = load_engine()
    data=engine.compute_totals()
    for k in  ('ns','ts','nd','hchc','hcch','hcrv','ccch','ccrv'):
        writer.writerow((engine.legend[k],))
        qs = (k in ('ns','ts','nd')) and ('autumn',) or engine.quarters+['total']
        row = [''] + ['%s %s' % (y,q) for y in engine.years for q in qs]
        writer.writerow(row)
        for category,qc in sorted(data.items()):
            row = [category] + [getattr(qc[y,q],k) for y in engine.years for q in qs]
            writer.writerow(row)
        writer.writerow([])
    return s.getvalue()


@auth.requires_login()
def srac():
    import os
    from gluon.template import render
    from gluon.contrib.markmin.markmin2pdf import latex2pdf
    if not session.model: redirect(URL('change'))
    engine = load_engine()
    data=engine.compute_totals()
    filename=os.path.join(request.folder,'views','default','reports.tex')
    today=request.now.strftime('%d %b %Y')
    year = int(request.args(0) or engine.forecast_year)
    context={'data':data,'engine':engine,'today':today,'year':year,'comp':comp,'model':session.model,'XML':XML}
    latex = render(filename=filename,context=context,delimiters=('[[',']]'))
    if request.extension=='pdf':
        return latex2pdf(latex)
    else:
        return latex

def test_srac():
    import os
    from gluon.template import render
    from gluon.contrib.markmin.markmin2pdf import latex2pdf
    if not session.model: redirect(URL('change'))
    engine = load_engine()
    data=engine.compute_totals()
    filename=os.path.join(request.folder,'views','default','reports_check.tex')
    today=request.now.strftime('%d %b %Y')
    year = int(request.args(0) or engine.forecast_year)
    context={'data':data,'engine':engine,'today':today,'year':year,'comp':comp,'model':session.model,'XML':XML}
    latex = render(filename=filename,context=context,delimiters=('[[',']]'))
    if request.extension=='pdf':
        return latex2pdf(latex)
    else:
        return latex


@auth.requires_login()
def assumptions():
    if not session.model: redirect(URL('change'))
    engine = load_engine()
    pricing = engine.pricing
    import pickle; pickle.dump(pricing,open('pricing2.pickle','w'))
    return dict(pricing=pricing, engine=engine)

@auth.requires(session.model and session.model['created_by']==auth.user_id)
def edit_assumption():
    key,value = request.vars.items()[0]
    key=key.split('_')
    year = int(key[-3])
    name = key[-2]
    cohort = int(key[-1])
    category = '/'.join(key[:-3])
    value = int(value or 0)
    key='%s/%s/%s/%s' % (category,year,name,cohort)
    engine = load_engine()
    engine.pricing[key]=value
    save_engine(engine)
    return ''

@auth.requires_login()
def splits():
    if not session.model: redirect(URL('change'))
    engine = load_engine()
    table = TABLE()
    year = engine.forecast_year
    form=SQLFORM.factory(
        Field('category',requires=IS_IN_SET(engine.data.keys())),
        Field('new_category',requires=IS_MATCH('[a-z]+(/[a-z]+)*')),
        Field('percentage','double',requires=IS_FLOAT_IN_RANGE(0,100),
              default=50))
    if form.accepts(request,session):
        if form.vars.new_category in engine.data:
            form.errors['new_category']='category already exists'
        else:
            engine.add_category(form.vars.new_category,form.vars.category,0)
            #dh = self.pricing.get('%s/%s/dh/0' % (category,year),0)
            #dy = self.pricing.get('%s/%s/dy/0' % (category,year),0)
            #mi = self.pricing.get('%s/%s/mi/0' % (category,year),0)
            #ma = self.pricing.get('%s/%s/ma/0' % (category,year),0)
            scale = form.vars.percentage/100
            engine.splits[year,form.vars.category] = (
                form.vars.category, 1.0-scale)
            engine.splits[year,form.vars.new_category] = (
                form.vars.category, scale)
            save_engine(engine)
    for key in sorted(engine.splits):
        category, year = key
        new_category, scale = engine.splits[key]
        table.append(TR(year, category, new_category, '%s%%' % int(100.0*scale)))
    return dict(table=table,form=form)

def user():
    return dict(form=auth())


def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request,db)
