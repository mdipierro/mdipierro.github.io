import gluon.portalocker
from cStringIO import StringIO
import cPickle
import sys
import os
from gluon import current

CC_TEST = False

# schools = ['commerce','communications','cdm', 'las','snl','law','music', 'theatre']
# careers = ['grad','ugrd','prof']
# groups = ['full','part']
# years = range(2007,2012) # ALWAYS FISCAL YEAR
# quarters = ['summer','autumn','winter','spring']
# categories = ['%s/%s/%s' % (x,y,z) for x in schools for y in careers for z in groups]

ROTATION = {'grad/commerce/commerce':1.0,
            'grad/communications/communications':1.0,
            'grad/cdm/cdm':1.0,
            'grad/las/las':1.0,
            'grad/snl/snl':1.0,
            'grad/law/law':1.0,
            'grad/music/music':1.0,
            'grad/theatre/theatre':1.0}

LEGEND={'ns':"New Students",
        'ts':"Transfer Students",
        'nd':"Non Degree",
        'hchc':"HeadCount (Home College)",
        'hcch':"Credit Hours (Home College)",
        'hcrv':"Revenues (Home College)",
        'ccch':"Credit Hours (Course College)",
        'ccrv':"Revenues (Course College)"}

def round(x): return max(int(0.5+x),0)
def divide(a,b): return b and float(a)/b or 0


def generic_price_scheme(mu,r,p1,p2):
    """
    mu is average number of courses
    p1 is fixed price in range r
    p2 is price per course above ny
    """
    price = p1
    a,b = r

    for i in range(0,a):
        x = float(i)/mu**2
        price += x*p2*i
    for i in range(b,int(mu*2)):
        x = float(2*mu-i)/mu**2
        price += x*p2*(i-b+1)
    return price

class Point(object):
    def __init__(self,actual=True):
        self.ns = 0   # new students
        self.ts = 0   # transfer students
        self.nd = 0   # budgeted non-degree students
        self.hchc = 0 # home college head count
        self.hcch = 0 # home college credit hours
        self.hcrv = 0 # home college revenues

        self.ccch = 0 # course college credit hours
        self.ccrv = 0 # course college revenues

        self.ns_budgeted = 0    # budgeted new students
        self.ts_budgeted = 0    # budgeted transfer students
        self.nd_budgeted = 0    # budgted non-degree students
        self.hchc_budgeted = 0  # budgeted home college head count
        self.hcch_budgeted = 0  # budgeted home college credit hours
        self.hcrv_budgeted = 0  # budgeted home college revenues

        self.price_course = 0   # 1 course = 4 credit hours
        self.price_fixed  = 0   #
        self.price_min  = 0     #
        self.price_max  = 0     #
        self.assumption = False
        self.actual = actual

def dict_to_point(obj):
    for category,v in obj.items():
        for (y,q),v2 in v.items():
            v[y,q] = p = Point()
            p.__dict__.update(v2)
    return obj

class Engine:
    def __init__(self,serialized=None):

        self.legend = LEGEND
        self.quarters = ['summer','autumn','winter','spring']
        self.data=data = {}
        self.rotation = ROTATION
        self.splits = {}

        if serialized:
            package = cPickle.loads(serialized)
            self.data = package['data']
            self.pricing = package['pricing']
            self.rotation = package['rotation']
            self.splits = package.get('splits',{})
        else:
            self.rotation = ROTATION
            f = open(os.path.join(current.request.folder,
                                  'modules/dump.pickle'),'rb')
            self.data = dict_to_point(cPickle.load(f))
            self.pricing = cPickle.load(open(os.path.join(
                        current.request.folder,'modules/pricing.pickle'),'rb'))
            self.rotation = ROTATION ### default behavior
            self.splits = {}

        self.years = list(set([x[0] for x in self.data[self.data.keys()[0]]]))
        if len(self.years)<3: raise RuntimeError, "Not enought data in file"
        self.years.sort()
        self.forecast_year = self.years[-1]
        self.schools = list(set([c.split('/')[0] for c in self.data]))
        self.schools.sort()

    def add_category(self,category,clone_category,scale=0):
        self.data[category] = d = {}
        for year_quarter, qc in self.data[clone_category].items():
            qd = d[year_quarter] = Point()
            for key in ('hchc','hcch','hcrv','ccch','ccrv','ns','ts','nd',
                        'hchc_budgeted','hcch_budgeted','hcrv_budgeted',
                        'ns_budgeted','ts_budgeted','nd_budgeted','actual','assumption'):
                setattr(qd,key,int(scale*getattr(qc,key)))

    def serialize(self):
        package={}
        package['data'] = self.data
        package['splits'] = self.splits
        package['pricing'] = self.pricing
        package['rotation'] = self.rotation
        return cPickle.dumps(package)

    def price(self,category,year,hc,ch,ns):
        """
        dh is dollars/credit/hour
        dy is dollars/year (fixed)
        mi is min numer of credit hours for dy
        ma is max number of credit hours for dy
        """
        avg_credit_hours = divide(ch,hc)

        key = '%s/%s/ch/0' % (category,year)
        if self.pricing.get(key,0): # overrdng pricing
            dh = self.pricing.get('%s/%s/dh/0' % (category,year),0)
            dy = self.pricing.get('%s/%s/dy/0' % (category,year),0)
            mi = self.pricing.get('%s/%s/mi/0' % (category,year),0)
            ma = self.pricing.get('%s/%s/ma/0' % (category,year),0)
            key_cohorts = '%s/%s/ch/1' % (category,year)
            if not self.pricing.get(key_cohorts,0): # pricing by cohorts!
                amount = hc * generic_price_scheme(avg_credit_hours,[mi,ma],dh,dy/3)
            else:
                vdh=[0,0,0,0,0]
                vdy=[0,0,0,0,0]
                vmi=[0,0,0,0,0]
                vma=[0,0,0,0,0]
                for i in (1,2,3,4):
                    vdh[i] = self.pricing.get(
                        '%s/%s/dh/%s' % (category,year,i),0)
                    vdy[i] = self.pricing.get(
                        '%s/%s/dy/%s' % (category,year,i),0)
                    vmi[i] = self.pricing.get(
                        '%s/%s/mi/%s' % (category,year,i),0)
                    vma[i] = self.pricing.get(
                        '%s/%s/ma/%s' % (category,year,i),0)
                amount = ns * generic_price_scheme(
                    avg_credit_hours,[mi,ma],dh,dy/3)
                for i in (1,2,3,4):
                    amount += 0.25*(hc-ns) * generic_price_scheme(
                        avg_credit_hours,[vmi[1],vma[1]],vdh[1],vdy[1]/3)

        elif '/ugrd' in category: # default for undergrads
            dh = self.pricing.get('/ugrd/%s/dh/0' % (year),0)
            dy = self.pricing.get('/ugrd/%s/dy/0' % (year),0)
            mi = self.pricing.get('/ugrd/%s/mi/0' % (year),0)
            ma = self.pricing.get('/ugrd/%s/ma/0' % (year),0)
            amount = hc * generic_price_scheme(
                avg_credit_hours,[mi,ma],dh,dy/3)
        elif '/grad' in category: # default for grads
            dh = self.pricing.get('/grad/%s/dh/0' % (year),0)
            dy = self.pricing.get('/grad/%s/dy/0' % (year),0)
            mi = self.pricing.get('/grad/%s/mi/0' % (year),0)
            ma = self.pricing.get('/grad/%s/ma/0' % (year),0)
            amount = hc * generic_price_scheme(
                avg_credit_hours,[mi,ma],dh,dy/3)
        else:
            amount = 1.0 # THIS SHOULD NOT BE THE CASE!!!!
        return int(amount)

    def compute(self,new_students=None):

        # determine actuals (only matters at first run)
        def f(qc): return qc.ns+qc.ts+qc.nd
        for y in self.years:
            for q in self.quarters:
                if sum(self.data[c][y,q].ns for c in self.data)==0:
                    for c in self.data: self.data[c][y,q].actual=False

        # compute total new students previous year and forecast year
        total_previous = sum(f(self.data[c][self.forecast_year-1,'autumn']) \
                                 for c in self.data)
        total_current = sum(f(self.data[c][self.forecast_year,'autumn']) \
                                for c in self.data)
        # allocate new students (autumn only)
        if total_current==0 or new_students==0:
            for category in self.data:
                qc = self.data[category][self.forecast_year,'autumn']
                ### BEGIN SPLITTING LOGIC ###
                try:
                    sc, scale = self.splits[self.forecast_year,category]
                except KeyError:
                    sc, scale = category, 1.0
                ### END SPLITTING LOGIC ###
                qc_previous = self.data[sc][self.forecast_year-1,'autumn']

                qc.ns = int(scale*qc_previous.ns)
                qc.ts = int(scale*qc_previous.ts)
                qc.nd = int(scale*qc_previous.nd)
                total_current += f(qc)

        # eventually re-scale them (autumn only)
        elif new_students:
            total=0
            for category in self.data:
                qc = self.data[category][self.forecast_year,'autumn']
                qc.ns = round(qc.ns*new_students/total_current)
                qc.ts = round(qc.ts*new_students/total_current)
                qc.nd = round(qc.nd*new_students/total_current)
                total += f(qc)
            total_current = total

        # compute hchc, hcch, hcrv (autumn fisrt, than adjust other terms)
        for category, dc in self.data.items():
            if category.startswith('total') or '/total' in category:
                raise RuntimeError, 'totals should not be stord'
            for year in self.years[2:]:
                for quarter in ('autumn',):
                    point = dc[year, quarter]
                    ### BEGIN SPLITTING LOGIC ###
                    try:
                        sc, scale = self.splits[year,category]
                    except KeyError:
                        sc, scale = category, 1.0
                    ### END SPLITTING LOGIC ###
                    opoint = self.data[sc][year-1,quarter]
                    oopoint = self.data[sc][year-2,quarter]
                    total_new_students=f(point)
                    ototal_new_students=f(opoint)
                    #
                    # this breaks if a split ocurred the year before last
                    #
                    if not (point.actual or point.assumption):
                        prob_continue = divide(opoint.hchc-ototal_new_students,
                                               oopoint.hchc)

                        average_ch_per_hc = divide(opoint.hcch,opoint.hchc)
                        rv_adjust = divide(opoint.hcrv,
                                           self.price(category,year,
                                                      opoint.hchc,
                                                      opoint.hcch,
                                                      ototal_new_students))

                        point.hchc = int(opoint.hchc * scale * prob_continue +\
                                             total_new_students)
                        point.hcch = int(point.hchc * average_ch_per_hc)
                        point.hcrv = int(self.price(
                                category,year,point.hchc,
                                point.hcch,total_new_students)*rv_adjust)

                for quarter in ('summer','winter','spring'):
                    point = dc[year, quarter]
                    if not point.actual:
                        point_autumn = dc[year, 'autumn']
                        ### BEGIN SPLITTING LOGIC ###
                        try:
                            sc, scale = self.splits[year,category]
                        except KeyError:
                            sc, scale = category, 1.0
                        ### END SPLITTING LOGIC ###
                        opoint = self.data[sc][year-1, quarter]

                        opoint_autumn = self.data[sc][year-1, 'autumn']

                        for key in ('hchc','hcch','hcrv','ns','ts','nd'):
                            value=round(divide(getattr(opoint,key)*\
                                                   getattr(point_autumn,key),
                                               getattr(opoint_autumn,key)))
                            setattr(point,key,value)

        ### compute course college from home college
        schools = list(set(x.split('/')[0] for x in self.data))

        for category in self.data: # <<<<< NO DATA FOR ROTATION
            dc=self.data[category]
            for year in self.years:
                for quarter in self.quarters:
                    point = dc[year,quarter]
                    if CC_TEST or not point.actual:
                        prev_point = dc[year-1,quarter]
                        point.ccch = prev_point.ccch
                        point.ccrv = prev_point.ccrv
                        keys = category.split('/')
                        school,career = keys[:2]
                        for oschool in self.schools:
                            ocategory=oschool+'/'+'/'.join(keys[1:])
                            okey = '%s/%s/%s' % (career, oschool, school)
                            default = (school==oschool) and 1.0 or 0.0
                            try:
                                opoint = self.data[ocategory][year,quarter]
                                prev_opoint = \
                                    self.data[ocategory][year-1,quarter]
                                point.ccch += \
                                    self.rotation.get(okey,default) * \
                                    (opoint.hcch-prev_opoint.hcch)
                                point.ccrv += \
                                    self.rotation.get(okey,default) * \
                                    (opoint.hcrv-prev_opoint.hcrv)
                            except KeyError:
                                pass
                        # safety - never happens
                        point.ccch = max(point.ccch,0)
                        point.ccrv = max(point.ccrv,0)


        return self.compute_totals()

    def compute_totals(self):
        import copy
        data = copy.deepcopy(self.data)
        data['total'] = {}
        for school in self.schools:
            data[school+'/total'] = {}
        for category in self.data:
            if 'total' in category: continue
            school = category.split('/')[0]
            dc=self.data[category]
            for x,y in dc.items():
                if x[1]=='total': continue
                if not x in data['total']:
                    data['total'][x]=Point(False)
                if not x in data[school+'/total']:
                    data[school+'/total'][x]=Point(False)
                for k in ('hchc','hcch','hcrv','ccch','ccrv','ns','ts','nd',
                          'hchc_budgeted','hcch_budgeted','hcrv_budgeted',
                          'ns_budgeted','ts_budgeted','nd_budgeted'):
                    setattr(data[school+'/total'][x],k,
                            getattr(data[school+'/total'][x],k)+getattr(y,k))
                    setattr(data['total'][x],k,
                            getattr(data['total'][x],k)+getattr(y,k))

        for category in data:
            dc = data[category]
            for x in dc.keys():
                dc[x[0],'total'] = Point(False)
            for x,y in dc.items():
                if x[1]!='total':
                    for k in ('hchc','hcch','hcrv','ccch','ccrv',
                              'ns','ts','nd',
                              'hchc_budgeted','hcch_budgeted','hcrv_budgeted',
                              'ns_budgeted','ts_budgeted','nd_budgeted'):
                        setattr(dc[x[0],'total'],k,
                                getattr(dc[x[0],'total'],k)+getattr(y,k))
        self.data_with_totals = data
        return data

    def new_autumn_students(self,year=None):
        y = year or self.forecast_year
        qc = self.data_with_totals['total'][y,'autumn']
        return int(qc.ns+qc.ts+qc.nd)
        # must run after compute
