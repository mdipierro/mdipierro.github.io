python csvstudio.py -t -q "location#STDYABROAD yearname=09-10  enrl_status_reason#(ENRL|EWAT)" < NateData/2011-02-14/crscoltuitionupload.csv
