import cPickle
import sys
import csv
import re

FILENAME1='../NateData/2011-02-14/tuitionUpload.csv'
FILENAME2='../NateData/2011-02-14/crscoltuitionupload.csv'
OUTPUT = 'dump.pickle'

#cols1=['enrolledonly','enrolledonlyhrs','tuition']
#cols2=['crs_hours','tuition']

# map collegenames as from in Nate Data (left) into new app (right)
map_collegenames = {
     'GR_CDM':'cdm/grad',
     'GR_Commerce':'commerce/grad',
     'GR_Communication':'communication/grad',
     'GR_Education':'education/grad',
     'GR_LAS':'las/grad',
     'GR_Music':'music/grad',
     'GR_SNL':'snl/grad',
     'GR_Theatre':'theatre/grad',
     'Inst for Prof Dev':'cdm/ipd',
     'Law':'law',
     'UG_CDM':'cdm/ugrd',
     'UG_Commerce':'commerce/ugrd',
     'UG_Communication':'communication/ugrd',
     'UG_Education':'education/ugrd',
     'UG_LAS':'las/ugrd',
     'UG_Music':'music/ugrd',
     'UG_SNL':'snl/ugrd',
     'UG_Theatre':'theatre/ugrd'}

# map termnames (lower case) from Nate into new app (as SRAC report)
QUARTERS = {'summer':'summer',
            'fall':'autumn',
            'winter':'winter',
            'spring':'spring'}

def Point(actual=True):
    " A point is a bucket (actual = True for imported data, False otherwise) "
    d = dict()
    d['hchc'] = 0 # home college head count
    d['hcch'] = 0 # home college credit hours
    d['hcrv'] = 0 # home college revenues
    d['ccch'] = 0 # course college credit hours
    d['ccrv'] = 0 # course college revenues
    d['ns'] = 0    # new students
    d['ts'] = 0    # transfer students
    d['nd'] = 0    # budgeted nondegree students

    d['ns_budgeted'] = 0    # budgeted new students
    d['ts_budgeted'] = 0    # budgeted transfer students
    d['nd_budgeted'] = 0    # budgted nondegree students
    d['hchc_budgeted'] = 0  # budgeted home college head count
    d['hcch_budgeted'] = 0  # budgeted home college credit hours
    d['hcrv_budgeted'] = 0  # budgeted home college revenues

    d['price_course'] = 0   # 1 course = 4 credit hours
    d['price_fixed']  = 0   #
    d['price_min']  = 0     #
    d['price_max']  = 0     #
    d['assumption'] = False
    d['actual'] = actual
    return d

def read_csv(filename):
    def tryparse(value):
        try:
            if '.' in value: return float(value)
            else: return int(value)
        except ValueError:
            return value.strip()
    keys=[]
    rows=[]
    cleanup = re.compile('[^\w_]+')
    reader =  csv.reader(open(filename,'r'))
    for number,line in enumerate(reader):
        if not number:
            keys = [cleanup.sub('_',key.lower()) for key in line]
            print 'keys',keys
        else:
            rows.append(dict((key,tryparse(line[k])) for k,key in enumerate(keys)))
    return rows

# get bucket, if not exists, make one
def get_bucket(data,key,yearname,termname,actual=True):
    year = 2000+int(yearname[-2:])
    quarter = QUARTERS[termname.lower()]
    if not key in data:
        data[key]={}
    try:
        return data[key][year,quarter]
    except KeyError:
        bucket = data[key][year,quarter] = Point(actual=actual)
        return bucket

# given a row from Nate CSV file, figure out what category it is
# no data loss!
def get_category(row):
    if not 'location' in row:
        # this is home college data
        collegename = map_collegenames[row['collegename']]
    else:
        # this is course college data
        collegename = map_collegenames[row['course_collegename']]
    category = collegename
    school = category.split('/')[0]
    if 'location' in row and row['location']=='STDYABROAD':
        category = school +'/abroad'
        stream2 = True
    elif 'location' in row and row['location']=='OVERSEAS' and \
            school in ('commerce','cdm','snl'):
        category = school +'/overseas'
    elif category == 'cdm/ipd':
        # ipd students are non-degree ugrd part time !!!!
        row['level_entry_descr'] = 'N(ipd)' # Exception, ipd count as non-degree
        category = 'cdm/ugrd/part'
    elif category.endswith('/ugrd') and not school in ('theatre','music','law','snl'):
        if row['fullpart']=='P':
            category = category+'/part'
        else:
            category = category+'/full'
    elif school=='law':
        if row['classname'].lower()=='llm':
            category = category+'/llm'
        elif row['classname'].lower()=='non-degree':
            category = category+'/nondegree'
        elif row['dayeve']=='EVE':
            category = category+'/jd/eve'
        else:
            category = category+'/jd/day'
    return school,category

def load(filename1=FILENAME1, filename2=FILENAME2):
    data = {}
    rows = read_csv(filename1)
    yearnames = list(set(row['yearname'] for row in rows))
    yearnames.sort()
    print 'yearnames=',yearnames
    termnames = list(set(row['termname'] for row in rows))
    print 'termnames=',termnames
    collegenames=list(set(row['collegename'] for row in rows))
    print 'collegenames',collegenames
    assert len(collegenames)==len(map_collegenames)
    assert [map_collegenames[x] for x in collegenames]
    nextyearname = '%.2i-%.2i' % (int(yearnames[-1][-2:]),int(yearnames[-1][-2:])+1)
    yearnames.append(nextyearname)

    checks1,checks2 = {},{}
    rows = read_csv(filename1)
    actuals = set()
    for row in rows:
        school, category = get_category(row)
        yearname = row['yearname']
        termname = row['termname']
        actuals.add((yearname,termname))
        bucket = get_bucket(data,category,yearname,termname)

        # this may be diffrent for LAW & SNL, check
        if school=='snl':
            if row['classname'][0] in 'J' or row['level_entry_descr'][0] in 'MN':
                bucket['ns'] += row['enrolledonly'] or 0
        elif school=='law':
            if row['classname'][0] in 'JFSS' and row['level_entry_descr'][0]=='P':
                bucket['ns'] += row['enrolledonly'] or 0
            if row['classname'][0] in 'L' and row['level_entry_descr'][0]=='PN':
                bucket['ns'] += row['enrolledonly'] or 0
            if row['classname'][0] in 'N':
                bucket['ns'] += row['enrolledonly'] or 0
        else:
            if row['level_entry_descr'][0] in 'FM':
                bucket['ns'] += row['enrolledonly'] or 0
            elif row['level_entry_descr'][0] == 'T':
                bucket['ts'] += row['enrolledonly'] or 0
            elif row['level_entry_descr'][0] == 'N':
                if '/grad' in category:
                    # grad non degree students are counted as new  studnets (doh!)
                    bucket['ns'] += row['enrolledonly'] or 0
                else:
                    bucket['nd'] += row['enrolledonly'] or 0

        bucket['hchc'] += row['enrolledonly'] or 0
        bucket['hcch'] += row['enrolledonlyhrs'] or 0
        bucket['hcrv'] += row['tuition'] or 0

        checks1[yearname] = checks1.get(yearname,0) + \
            (row['enrolledonlyhrs'] or 0)

        # some care here because reading LAW CC from HC (no rotation)
        if school=='law':
            bucket['ccch'] = bucket['hcch']
            bucket['ccrv'] = bucket['hcrv']
            checks2[yearname] = checks2.get(yearname,0) + (row['enrolledonlyhrs'] or 0)

    rows = read_csv(filename2)
    for row in rows:
        # we ignore students who dropped before deadline
        if not row['enrl_status_reason'] in ('ENRL','EWAT'):
            continue
        # some care here because reading LAW CC from HC (no rotation)
        if row['course_collegename'].lower()=='law':
            continue
        school, category = get_category(row)
        yearname = row['yearname']
        termname = row['termname']
        bucket = get_bucket(data,category,yearname,termname)
        bucket['ccch'] += row['crs_hours'] or 0
        bucket['ccrv'] += row['tuition'] or 0
        checks2[yearname] = checks2.get(yearname,0) + (row['crs_hours'] or 0)

    for key in sorted(checks1):
        print key, checks1[key], checks2.get(key,None)

    # fill in missing buckets (buckets in future are actual=False)
    for key in data:
        for yearname in yearnames:
            for termname in termnames:
                actual = (yearname,termname) in actuals
                get_bucket(data,key,yearname,termname,actual=actual)

    return data

def save(data,output=OUTPUT):
    f=open(output,'wb')
    cPickle.dump(data,f)
    f.close()

print """
this programs reads
%s
%s
and outputs: %s
""" % (FILENAME1, FILENAME2, OUTPUT)
save(load())
