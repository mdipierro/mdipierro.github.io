# -*- coding: utf-8 -*-
# this file is released under public domain and you can use without limitations
# http://hostname/app/deafult/index
# http://hostname/app/deafult/create_post/<category>
# http://hostname/app/deafult/edit_post/<id>
# http://hostname/app/deafult/list_posts_by_datetime/<category>/<page>
# http://hostname/app/deafult/list_posts_by_votes/<category>/<page>
# http://hostname/app/deafult/list_posts_by_author/<user_id>/<page>
# http://hostname/app/deafult/view_post/<id>
# http://hostname/app/deafult/vote_post/<id>/<up or down>
# http://hostname/app/deafult/comm_vote_post/<comm_id>/<up or down>

POSTS_PER_PAGE = 10

def get_category():
    category_name = request.args(0)
    category = db.category(name=category_name)
    if not category:
        session.flash = 'page not found'
        redirect(URL('index'))
    return category

def index():
    rows = db(db.category).select()
    return locals()

@auth.requires_login()
def create_post():
    category = get_category()
    db.post.category.default = category.id
    form = SQLFORM(db.post).process(next='view_post/[id]')
    return locals()

@auth.requires_login()
def edit_post():
    id = request.args(0,cast=int)
    form = SQLFORM(db.post, id, showid=False).process(next='view_post/[id]')
    return locals()

def list_posts_by_datetime():
    response.view = 'default/list_posts_by_votes.html'
    category = get_category()
    page = request.args(1,cast=int,default=0)
    start = page*POSTS_PER_PAGE
    stop = start+POSTS_PER_PAGE
    rows = db(db.post.category==category.id).select(orderby=~db.post.created_on,limitby=(start,stop))
    return locals()

def list_posts_by_votes():    
    category = get_category()
    page = request.args(1,cast=int,default=0)    
    start = page*POSTS_PER_PAGE
    stop = start+POSTS_PER_PAGE
    rows = db(db.post.category==category.id).select(orderby=~db.post.votes,limitby=(start,stop))
    return locals()

def list_posts_by_author():
    response.view = 'default/list_posts_by_votes.html'
    user_id = request.args(0,cast=int)
    page = request.args(1,cast=int,default=0)
    start = page*POSTS_PER_PAGE
    stop = start+POSTS_PER_PAGE
    rows = db(db.post.created_by==user_id).select(orderby=~db.post.created_on,limitby=(start,stop))
    return locals()

def view_post():
    id = request.args(0,cast=int)
    post = db.post(id) or redirect(URL('index'))
    comment = db(db.comm.post==post.id).select(orderby=~db.comm.created_on,limitby=(0,1)).first()
    if auth.user:
        db.comm.post.default = id
        db.comm.parent_comm.default = comment.id if comment else None
        form = SQLFORM(db.comm).process()
    else:
        form = A("login to comment",_href=URL('user/login',vars=dict(_next=URL(args=request.args))))
    comments = db(db.comm.post==post.id).select(orderby=db.comm.created_on)
    return locals()

# http://hostname/app/default/vote_callback?id=2&direction=up

def vote_callback():
    vars = request.post_vars
    if vars and auth.user:
        id = vars.id
        direction = +1 if vars.direction == 'up' else -1
        post = db.post(id)
        if post:
            vote = db.vote(post=id,created_by=auth.user.id)
            if not vote:
                post.update_record(votes=post.votes+direction)
                db.vote.insert(post=id,score=direction)
            elif vote.score!=direction:
                post.update_record(votes=post.votes+direction*2)
                vote.update_record(score=direction)
            else:
                pass # voter voted twice in same direction
        print post.votes
    if vars and not auth.user:
         post = db.post(vars.id)
         response.flash = "You must be logged in to vote!"
    return str(post.votes)

def comm_vote_callback():
    vars = request.post_vars
    if vars and auth.user:
        id = vars.id
        direction = +1 if vars.direction == 'up' else -1
        comm = db.comm(id)
        if comm:
            vote = db.comm_vote(comm=id,created_by=auth.user.id)
            if not vote:
                comm.update_record(votes=comm.votes+direction)
                db.comm_vote.insert(comm=id,score=direction)
            elif vote.score!=direction:
                comm.update_record(votes=comm.votes+direction*2)
                vote.update_record(score=direction)
            else:
                pass # voter voted twice in same direction
        print comm.votes
    return str(comm.votes)
    


def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/manage_users (requires membership in
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    """
    return dict(form=auth())

@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service()


@auth.requires_signature()
def data():
    """
    http://..../[app]/default/data/tables
    http://..../[app]/default/data/create/[table]
    http://..../[app]/default/data/read/[table]/[id]
    http://..../[app]/default/data/update/[table]/[id]
    http://..../[app]/default/data/delete/[table]/[id]
    http://..../[app]/default/data/select/[table]
    http://..../[app]/default/data/search/[table]
    but URLs must be signed, i.e. linked with
      A('table',_href=URL('data/tables',user_signature=True))
    or with the signed load operator
      LOAD('default','data.load',args='tables',ajax=True,user_signature=True)
    """
    return dict(form=crud())
