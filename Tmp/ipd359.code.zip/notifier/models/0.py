EMAIL_SERVER = 'logging'
EMAIL_SENDER = 'massimo.dipierro@gmail.com'
EMAIL_LOGIN = None
EMAIL_POLICY = 'realtime' # 'deferred'
